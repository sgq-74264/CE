'use strict';
/**
 * 端到端自测脚本（需要先启动服务）
 * 用法：node scripts/e2e-test.js
 * 覆盖：注册登录 / 发布托管 / 接单取件送达 / 结算 / 评价 / 取消退款 / 权限守卫
 */
const BASE = process.env.BASE || 'http://localhost:3000';
let passed = 0;
let failed = 0;

function ok(name, cond, extra = '') {
  if (cond) {
    passed++;
    console.log(`  ✅ ${name}`);
  } else {
    failed++;
    console.log(`  ❌ ${name} ${extra}`);
  }
}

async function api(method, path, { token, body } = {}) {
  const res = await fetch(`${BASE}/api${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  return { status: res.status, json: await res.json() };
}

async function main() {
  console.log(`\n🚀 端到端测试 → ${BASE}\n`);

  // ---------- 注册与登录 ----------
  console.log('▶ 账号体系');
  const suffix = Date.now().toString(36);
  let r = await api('POST', '/auth/register', {
    body: { username: `stu_${suffix}`, password: 'test123456', nickname: '测试学生', role: 'student', dorm: '1号楼 101' },
  });
  ok('注册学生账号', r.json.success === true, r.json.message);
  const stu = r.json.data;

  r = await api('POST', '/auth/register', {
    body: { username: `run_${suffix}`, password: 'test123456', nickname: '测试跑腿', role: 'courier' },
  });
  ok('注册跑腿账号', r.json.success === true, r.json.message);
  const run = r.json.data;

  r = await api('POST', '/auth/login', { body: { username: `stu_${suffix}`, password: 'wrong-pass' } });
  ok('错误密码被拒绝', r.status === 401);
  r = await api('POST', '/auth/login', { body: { username: `stu_${suffix}`, password: 'test123456' } });
  ok('正确密码登录', r.json.success === true && !!r.json.data.token);

  // ---------- 充值与发布 ----------
  console.log('\n▶ 资金托管');
  r = await api('POST', '/wallet/recharge', { token: stu.token, body: { amount: 10000 } });
  ok('充值 ¥100', r.json.success === true && r.json.data.balance === 10000, JSON.stringify(r.json));

  r = await api('POST', '/orders', {
    token: stu.token,
    body: {
      expressCompany: '顺丰速运', trackingNo: 'SFE2E测试123', pickupPoint: '东区菜鸟驿站',
      deliveryAddress: '1号楼 101', itemDesc: '测试包裹', size: 'small',
      fee: 500, tip: 100, deadline: '2099-01-01T12:00', remark: '端到端测试',
    },
  });
  ok('发布订单（UTF-8 中文）', r.json.success === true && r.json.data.expressCompany === '顺丰速运', r.json.message);
  const order = r.json.data;

  r = await api('GET', '/me', { token: stu.token });
  ok('发布后托管扣款 ¥6', r.json.data.balance === 9400, `balance=${r.json.data.balance}`);

  // ---------- 状态机与权限 ----------
  console.log('\n▶ 订单状态机与权限');
  r = await api('POST', `/orders/${order.id}/accept`, { token: stu.token });
  ok('学生不能接单', r.status === 403, `status=${r.status}`);
  r = await api('POST', `/orders/${order.id}/accept`, { token: run.token });
  ok('跑腿员接单', r.json.success === true && r.json.data.status === 'accepted', r.json.message);
  r = await api('POST', `/orders/${order.id}/accept`, { token: run.token });
  ok('重复接单被拒绝(409)', r.status === 409);
  r = await api('POST', `/orders/${order.id}/deliver`, { token: run.token });
  ok('跳过取件直接送达被拒绝', r.status === 409);
  r = await api('POST', `/orders/${order.id}/pickup`, { token: run.token });
  ok('取件', r.json.data.status === 'picked');
  r = await api('POST', `/orders/${order.id}/complete`, { token: stu.token });
  ok('未送达时确认收货被拒绝', r.status === 409);
  r = await api('POST', `/orders/${order.id}/deliver`, { token: run.token });
  ok('送达', r.json.data.status === 'delivered');
  r = await api('POST', `/orders/${order.id}/cancel`, { token: stu.token, body: { reason: 'x' } });
  ok('送达后不能取消', r.status === 409);

  r = await api('POST', `/orders/${order.id}/complete`, { token: run.token });
  ok('跑腿员不能替用户确认收货', r.status === 403);
  r = await api('POST', `/orders/${order.id}/complete`, { token: stu.token });
  ok('确认收货完成', r.json.data.status === 'completed', r.json.message);

  r = await api('GET', '/me', { token: run.token });
  ok('跑腿员结算到账 ¥6', r.json.data.balance === 600, `balance=${r.json.data.balance}`);
  r = await api('GET', '/me', { token: stu.token });
  ok('学生余额保持 ¥94（已支出）', r.json.data.balance === 9400, `balance=${r.json.data.balance}`);

  // ---------- 评价 ----------
  console.log('\n▶ 评价系统');
  r = await api('POST', `/orders/${order.id}/review`, { token: run.token, body: { rating: 5 } });
  ok('跑腿员不能自评', r.status === 403);
  r = await api('POST', `/orders/${order.id}/review`, { token: stu.token, body: { rating: 5, content: '非常快，好评！' } });
  ok('发布人评价 5 星', r.json.success === true && r.json.data.rating === 5, r.json.message);
  r = await api('POST', `/orders/${order.id}/review`, { token: stu.token, body: { rating: 4 } });
  ok('重复评价被拒绝', r.status === 409);

  // ---------- 取消与退款 ----------
  console.log('\n▶ 取消退款');
  r = await api('POST', '/orders', {
    token: stu.token,
    body: { expressCompany: '中通快递', trackingNo: 'ZT取消测试999', pickupPoint: '西区快递中心', deliveryAddress: '1号楼 101', size: 'small', fee: 400 },
  });
  const order2 = r.json.data;
  r = await api('POST', `/orders/${order2.id}/cancel`, { token: stu.token, body: { reason: '不需要了' } });
  ok('取消订单', r.json.data.status === 'cancelled', r.json.message);
  r = await api('GET', '/me', { token: stu.token });
  ok('取消后全额退款（余额回到 ¥94）', r.json.data.balance === 9400, `balance=${r.json.data.balance}`);

  // ---------- 超时自动退款 ----------
  console.log('\n▶ 超时保护');
  r = await api('POST', '/orders', {
    token: stu.token,
    body: { expressCompany: '韵达快递', trackingNo: 'YD超时测试888', pickupPoint: '南区韵达驿站', deliveryAddress: '1号楼 101', size: 'small', fee: 300, deadline: '2020-01-01T00:00' },
  });
  ok('过去时间的截止日期被拒绝', r.status === 400, `status=${r.status}`);

  // ---------- 消息与流水 ----------
  console.log('\n▶ 消息与流水');
  r = await api('GET', '/notifications', { token: stu.token });
  ok('收到站内消息', r.json.success === true && r.json.data.total > 0);
  r = await api('POST', '/notifications/read', { token: stu.token, body: { all: true } });
  ok('全部已读', r.json.data.unread === 0);
  r = await api('GET', '/wallet?pageSize=50', { token: stu.token });
  const tx = r.json.data.list;
  ok('资金流水完整', tx.length >= 4, `len=${tx.length}`);
  const sum = tx.reduce((acc, t) => acc + t.amount, 0);
  ok('流水加和与余额自洽', sum === r.json.data.balance, `sum=${sum} balance=${r.json.data.balance}`);

  // ---------- 管理后台 ----------
  console.log('\n▶ 管理后台');
  r = await api('POST', '/auth/login', { body: { username: 'admin', password: 'admin123' } });
  const admin = r.json.data;
  r = await api('GET', '/admin/overview', { token: admin.token });
  ok('管理员查看总览', r.json.success === true);
  r = await api('GET', '/admin/overview', { token: stu.token });
  ok('学生访问管理接口被拒绝(403)', r.status === 403);
  r = await api('PUT', `/admin/users/${run.user ? run.user.id : 0}/status`, { token: admin.token, body: { status: 'banned' } });
  ok('管理员禁用用户', r.json.success === true, r.json.message);
  r = await api('POST', '/auth/login', { body: { username: `run_${suffix}`, password: 'test123456' } });
  ok('被禁用账号无法登录(403)', r.status === 403);
  r = await api('PUT', `/admin/users/${run.user.id}/status`, { token: admin.token, body: { status: 'active' } });
  ok('恢复用户', r.json.success === true);

  console.log(`\n════════════════════════════════`);
  console.log(`  结果：${passed} 通过 / ${failed} 失败`);
  console.log(`════════════════════════════════\n`);
  process.exit(failed > 0 ? 1 : 0);
}

main().catch((err) => {
  console.error('测试运行异常：', err);
  process.exit(1);
});
