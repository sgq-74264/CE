'use strict';
/**
 * 视图：钱包 / 消息中心 / 个人中心 / 用户主页 / 管理后台
 */

// ================================ 钱包 ================================
Views.wallet = async (container) => {
  const state = { page: 1 };
  const TYPE_CHIP = { recharge: '充值', withdraw: '提现', escrow_freeze: '托管冻结', escrow_release: '结算到账', escrow_refund: '退款' };

  async function load() {
    container.innerHTML = `<div class="page-loading"><div class="spinner"></div><p>加载钱包中…</p></div>`;
    let data;
    try {
      data = await Api.get(`/wallet?page=${state.page}&pageSize=12`);
    } catch (err) {
      UI.toast(err.message, 'error');
      data = { balance: 0, list: [], total: 0, page: 1, pageSize: 12 };
    }
    Api.updateUser({ ...(Api.getUser() || {}), balance: data.balance });
    window.renderHeader();

    const rows = data.list
      .map((t) => `
        <tr>
          <td><span class="tag">${TYPE_CHIP[t.type] || t.type}</span></td>
          <td>${UI.esc(t.note)}${t.orderNo ? `<br /><small class="muted">${UI.esc(t.orderNo)}</small>` : ''}</td>
          <td class="num tx-amount ${t.amount >= 0 ? 'pos' : 'neg'}">${t.amount >= 0 ? '+' : ''}${UI.yuan(t.amount)}</td>
          <td class="num">${UI.yuan(t.balanceAfter)}</td>
          <td class="muted">${UI.fmtTime(t.createdAt)}</td>
        </tr>`)
      .join('');

    container.innerHTML = `
      <div class="page-head view-enter">
        <div>
          <h1>我的钱包</h1>
          <p class="page-desc">充值发布任务，完成跑腿赚取收入，资金流水清晰可查</p>
        </div>
      </div>
      <div class="wallet-hero view-enter">
        <div>
          <div class="wh-label">当前余额（元）</div>
          <div class="wh-value"><span class="yuan">¥</span>${UI.money(data.balance)}</div>
        </div>
        <div class="wh-actions">
          <button class="btn btn-lg btn-white" id="rechargeBtn">💳 充值</button>
          <button class="btn btn-lg btn-outline-white" id="withdrawBtn">💸 提现</button>
        </div>
      </div>
      <div class="card view-enter">
        <div class="card-pad" style="padding-bottom:6px">
          <div class="card-title">资金流水</div>
          <div class="card-sub">托管冻结 · 结算到账 · 退款，每一笔都有据可查</div>
        </div>
        <div class="table-wrap" style="border:none;box-shadow:none;border-radius:0">
          <table class="table">
            <thead><tr><th>类型</th><th>说明</th><th class="num">金额</th><th class="num">余额</th><th>时间</th></tr></thead>
            <tbody>${rows || `<tr><td colspan="5" style="text-align:center;color:var(--ink-3);padding:36px">暂无流水记录</td></tr>`}</tbody>
          </table>
        </div>
        <div class="card-pad">${UI.pagination(data.page, data.pageSize, data.total)}</div>
      </div>`;

    container.querySelectorAll('.page-btn').forEach((b) =>
      b.addEventListener('click', () => {
        state.page = Number(b.dataset.page);
        load();
      })
    );
    container.querySelector('#rechargeBtn').addEventListener('click', () => moneyModal('recharge'));
    container.querySelector('#withdrawBtn').addEventListener('click', () => moneyModal('withdraw'));

    function moneyModal(kind) {
      const isRecharge = kind === 'recharge';
      UI.openModal({
        title: isRecharge ? '💰 充值' : '💸 提现',
        body: `
          <p class="muted mb-16" style="font-size:13px">${isRecharge ? '选择或输入充值金额（模拟支付，即时到账）' : `可提现余额：¥${UI.money(data.balance)}`}</p>
          <div class="chip-group mb-16" id="amountChips">
            ${[10, 20, 50, 100].map((v) => `<button type="button" class="chip-option ${v === 20 ? 'selected' : ''}" data-amount="${v * 100}">¥${v}</button>`).join('')}
          </div>
          <div class="field">
            <label>金额（元）</label>
            <input class="input" id="amountInput" type="number" min="1" max="10000" step="0.01" value="20" />
          </div>`,
        footer: `<button class="btn btn-ghost" id="moneyCancel">取消</button>
                 <button class="btn btn-primary" id="moneyOk">${isRecharge ? '确认充值' : '确认提现'}</button>`,
      });
      const input = document.getElementById('amountInput');
      document.querySelectorAll('#amountChips .chip-option').forEach((chip) => {
        chip.addEventListener('click', () => {
          document.querySelectorAll('#amountChips .chip-option').forEach((c) => c.classList.remove('selected'));
          chip.classList.add('selected');
          input.value = (Number(chip.dataset.amount) / 100).toFixed(0);
        });
      });
      document.getElementById('moneyCancel').onclick = () => UI.closeModal();
      document.getElementById('moneyOk').onclick = async () => {
        const amount = Math.round(Number(input.value) * 100);
        if (!Number.isInteger(amount) || amount < 100 || amount > 1000000) {
          UI.toast('金额需在 ¥1 ~ ¥10000 之间', 'error');
          return;
        }
        try {
          const r = isRecharge
            ? await Api.post('/wallet/recharge', { amount })
            : await Api.post('/wallet/withdraw', { amount });
          UI.closeModal();
          UI.toast(isRecharge ? `充值成功，到账 ¥${UI.money(amount)}` : `提现申请成功，扣除 ¥${UI.money(amount)}`, 'success');
          Api.updateUser({ ...(Api.getUser() || {}), balance: r.balance });
          window.refreshHeaderBadges && window.refreshHeaderBadges();
          load();
        } catch (err) {
          UI.toast(err.message, 'error');
        }
      };
    }
  }

  await load();
};

// ================================ 消息中心 ================================
Views.messages = async (container) => {
  const state = { page: 1, unread: '' };

  async function load() {
    container.innerHTML = `<div class="page-loading"><div class="spinner"></div><p>加载消息中…</p></div>`;
    let data;
    try {
      const qs = new URLSearchParams({ page: state.page, pageSize: 15 });
      if (state.unread) qs.set('unread', '1');
      data = await Api.get(`/notifications?${qs}`);
    } catch (err) {
      UI.toast(err.message, 'error');
      data = { list: [], total: 0, unread: 0, page: 1, pageSize: 15 };
    }

    const items = data.list
      .map((m) => `
        <div class="msg-item ${m.isRead ? '' : 'unread'}" data-id="${m.id}" data-order="${m.orderId || ''}">
          <div class="msg-icon ${m.type}">${m.type === 'wallet' ? '💰' : m.type === 'order' ? '📮' : '🔔'}</div>
          <div class="msg-body">
            <div class="msg-title">${m.isRead ? '' : '<span class="unread-dot"></span>'}${UI.esc(m.title)}</div>
            <div class="msg-content">${UI.esc(m.content)}</div>
            <div class="msg-time">${UI.timeAgo(m.createdAt)}</div>
          </div>
        </div>`)
      .join('');

    container.innerHTML = `
      <div class="page-head view-enter">
        <div>
          <h1>消息中心</h1>
          <p class="page-desc">订单动态、资金变动、系统通知都会出现在这里（未读 ${data.unread} 条）</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-ghost" id="readAllBtn">✅ 全部标为已读</button>
          <button class="btn ${state.unread ? 'btn-primary' : 'btn-ghost'}" id="unreadOnlyBtn">仅看未读</button>
        </div>
      </div>
      ${data.list.length
        ? `<div class="msg-list view-enter">${items}</div>${UI.pagination(data.page, data.pageSize, data.total)}`
        : `<div class="empty view-enter"><div class="empty-emoji">📭</div><h3>没有消息</h3><p>${state.unread ? '没有未读消息，全部已读' : '订单和资金动态会在这里通知你'}</p></div>`}`;

    container.querySelector('#readAllBtn').addEventListener('click', async () => {
      try {
        await Api.post('/notifications/read', { all: true });
        UI.toast('已全部标为已读', 'success');
        window.refreshHeaderBadges && window.refreshHeaderBadges();
        load();
      } catch (err) {
        UI.toast(err.message, 'error');
      }
    });
    container.querySelector('#unreadOnlyBtn').addEventListener('click', () => {
      state.unread = state.unread ? '' : '1';
      state.page = 1;
      load();
    });
    container.querySelectorAll('.page-btn').forEach((b) =>
      b.addEventListener('click', () => {
        state.page = Number(b.dataset.page);
        load();
      })
    );
    container.querySelectorAll('.msg-item').forEach((item) =>
      item.addEventListener('click', async () => {
        try {
          await Api.post('/notifications/read', { ids: [Number(item.dataset.id)] });
          window.refreshHeaderBadges && window.refreshHeaderBadges();
        } catch (_) {
          /* 跳转优先 */
        }
        if (item.dataset.order) location.hash = `#/order/${item.dataset.order}`;
        else load();
      })
    );
  }

  await load();
};

// ================================ 个人中心 ================================
Views.me = async (container) => {
  let me;
  try {
    me = await Api.get('/me');
    Api.updateUser(me);
  } catch (err) {
    UI.toast(err.message, 'error');
    location.hash = '#/login';
    return;
  }
  let stats = { published: 0, completed: 0, cancelled: 0, spent: 0, frozen: 0, taken: 0, takenCompleted: 0, earned: 0, avgRating: null, ratingCount: 0 };
  let profile = { reviews: [], stats: {} };
  try {
    stats = await Api.get('/orders/stats');
    profile = await Api.get(`/users/${me.id}`);
  } catch (_) {
    /* 统计失败不阻塞页面 */
  }

  container.innerHTML = `
  <div class="page-head view-enter">
    <div>
      <h1>个人中心</h1>
      <p class="page-desc">管理你的资料、安全设置，查看个人信用数据</p>
    </div>
    <div class="page-actions">
      <a class="btn btn-ghost" href="#/wallet">💰 我的钱包</a>
    </div>
  </div>

  <div class="card card-pad mb-16 view-enter">
    <div class="flex-center mb-16">
      ${UI.avatarHtml(me.nickname, me.id, 'lg')}
      <div>
        <h2 style="font-size:20px;display:flex;align-items:center;gap:8px">
          ${UI.esc(me.nickname)}
          <span class="badge badge-role">${UI.ROLE_LABEL[me.role] || me.role}</span>
        </h2>
        <p class="muted">@${UI.esc(me.username)} · 加入于 ${UI.fmtTime(me.createdAt).slice(0, 10)}${me.dorm ? ` · 🏠 ${UI.esc(me.dorm)}` : ''}</p>
      </div>
    </div>
    <div class="stat-grid">
      ${UI.statTile('发布订单', UI.compact(stats.published), `完成 ${stats.completed} · 取消 ${stats.cancelled}`)}
      ${UI.statTile('接单跑腿', UI.compact(stats.taken), `完成 ${stats.takenCompleted}`)}
      ${UI.statTile('累计消费', UI.yuan(stats.spent), '已完成订单的代取费')}
      ${UI.statTile('累计收入', UI.yuan(stats.earned), '跑腿结算所得')}
      ${UI.statTile('服务评分', stats.avgRating === null ? '—' : stats.avgRating, `${stats.ratingCount} 条评价`, stats.avgRating === null ? '' : ' 分')}
    </div>
  </div>

  <div class="detail-grid view-enter">
    <div class="card card-pad">
      <div class="card-title">编辑资料</div>
      <div class="card-sub">保持信息准确，方便跑腿员联系你</div>
      <form id="profileForm">
        <div class="form-row">
          <div class="field"><label>昵称</label><input class="input" name="nickname" value="${UI.esc(me.nickname)}" maxlength="20" /></div>
          <div class="field"><label>手机号</label><input class="input" name="phone" value="${UI.esc(me.phone)}" maxlength="11" placeholder="选填" /></div>
        </div>
        <div class="field"><label>宿舍 / 地址</label><input class="input" name="dorm" value="${UI.esc(me.dorm)}" maxlength="50" placeholder="如：3号宿舍楼 512" /></div>
        <div class="field"><label>个人简介</label><input class="input" name="bio" value="${UI.esc(me.bio)}" maxlength="100" placeholder="介绍一下自己吧" /></div>
        <button class="btn btn-primary" type="submit">保存资料</button>
      </form>
      <div class="divider"></div>
      <div class="card-title">修改密码</div>
      <div class="card-sub">定期修改密码，保障账号安全</div>
      <form id="pwdForm">
        <div class="form-row">
          <div class="field"><label>原密码</label><input class="input" name="oldPassword" type="password" required /></div>
          <div class="field"><label>新密码</label><input class="input" name="newPassword" type="password" placeholder="至少 6 位" required /></div>
        </div>
        <button class="btn btn-ghost" type="submit">修改密码</button>
      </form>
    </div>

    <div class="card card-pad">
      <div class="card-title">我收到的评价</div>
      <div class="card-sub">来自发布人的服务反馈</div>
      ${(profile.reviews && profile.reviews.length)
        ? profile.reviews.map((r) => `
            <div class="review-box mb-8">
              <div class="review-stars">${'★'.repeat(r.rating)}${'☆'.repeat(5 - r.rating)}</div>
              ${r.review ? `<div class="review-text">${UI.esc(r.review)}</div>` : '<div class="review-text muted">未填写文字评价</div>'}
              <div class="muted mt-8" style="font-size:12px">${UI.esc(r.publisherName)} · ${UI.fmtTime(r.createdAt)}</div>
            </div>`).join('')
        : '<p class="muted">还没有收到评价</p>'}
    </div>
  </div>`;

  container.querySelector('#profileForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    try {
      const updated = await Api.put('/me', {
        nickname: fd.get('nickname'),
        phone: fd.get('phone') || '',
        dorm: fd.get('dorm') || '',
        bio: fd.get('bio') || '',
      });
      Api.updateUser(updated);
      window.renderHeader();
      UI.toast('资料已更新', 'success');
    } catch (err) {
      UI.toast(err.message, 'error');
    }
  });

  container.querySelector('#pwdForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    try {
      await Api.put('/me/password', { oldPassword: fd.get('oldPassword'), newPassword: fd.get('newPassword') });
      UI.toast('密码修改成功', 'success');
      e.target.reset();
    } catch (err) {
      UI.toast(err.message, 'error');
    }
  });
};

// ================================ 用户主页 ================================
Views.user = async (container, params) => {
  let data;
  try {
    data = await Api.get(`/users/${params.id}`);
  } catch (err) {
    container.innerHTML = `<div class="empty view-enter"><div class="empty-emoji">😕</div><h3>用户不存在</h3><p>${UI.esc(err.message)}</p><a class="btn btn-primary" href="#/board">返回任务大厅</a></div>`;
    return;
  }
  const u = data.user;
  container.innerHTML = `
  <div class="card card-pad view-enter mb-16">
    <div class="flex-center mb-16">
      ${UI.avatarHtml(u.nickname, u.id, 'lg')}
      <div>
        <h2 style="font-size:20px;display:flex;align-items:center;gap:8px">
          ${UI.esc(u.nickname)}
          <span class="badge badge-role">${UI.ROLE_LABEL[u.role] || u.role}</span>
          ${u.status === 'banned' ? '<span class="badge badge-expired">已禁用</span>' : ''}
        </h2>
        <p class="muted">加入于 ${UI.fmtTime(u.createdAt).slice(0, 10)}${u.bio ? ` · ${UI.esc(u.bio)}` : ''}</p>
      </div>
    </div>
    <div class="stat-grid">
      ${UI.statTile('跑腿完成', UI.compact(data.stats.courierCompleted), '累计送达的订单')}
      ${UI.statTile('服务评分', data.stats.avgRating === null ? '—' : data.stats.avgRating, `${data.stats.ratingCount} 条评价`, data.stats.avgRating === null ? '' : ' 分')}
      ${UI.statTile('发布订单', UI.compact(data.stats.published), '发布的代取需求')}
    </div>
  </div>
  <div class="card card-pad view-enter">
    <div class="card-title">收到的评价</div>
    <div class="card-sub">来自真实交易的服务反馈</div>
    ${(data.reviews && data.reviews.length)
      ? data.reviews.map((r) => `
          <div class="review-box mb-8">
            <div class="review-stars">${'★'.repeat(r.rating)}${'☆'.repeat(5 - r.rating)}</div>
            ${r.review ? `<div class="review-text">${UI.esc(r.review)}</div>` : '<div class="review-text muted">未填写文字评价</div>'}
            <div class="muted mt-8" style="font-size:12px">${UI.esc(r.publisherName)} · ${UI.fmtTime(r.createdAt)}</div>
          </div>`).join('')
      : '<p class="muted">还没有收到评价</p>'}
  </div>`;
};

// ================================ 管理后台 ================================
Views.admin = async (container, params) => {
  const user = Api.getUser();
  if (!user || user.role !== 'admin') {
    container.innerHTML = `<div class="empty view-enter"><div class="empty-emoji">🔒</div><h3>无权访问</h3><p>该页面仅管理员可见</p><a class="btn btn-primary" href="#/">返回首页</a></div>`;
    return;
  }
  const tab = (params && params.tab) || 'overview';

  container.innerHTML = `
    <div class="page-head view-enter">
      <div>
        <h1>管理后台</h1>
        <p class="page-desc">平台数据总览、用户管理与订单监管</p>
      </div>
    </div>
    <div class="tabs view-enter">
      <button class="tab ${tab === 'overview' ? 'active' : ''}" data-tab="overview">📊 平台总览</button>
      <button class="tab ${tab === 'users' ? 'active' : ''}" data-tab="users">👥 用户管理</button>
      <button class="tab ${tab === 'orders' ? 'active' : ''}" data-tab="orders">📦 订单监管</button>
    </div>
    <div id="adminBody"><div class="page-loading"><div class="spinner"></div><p>加载中…</p></div></div>`;

  container.querySelectorAll('.tab').forEach((t) =>
    t.addEventListener('click', () => {
      location.hash = `#/admin/${t.dataset.tab}`;
    })
  );

  const body = container.querySelector('#adminBody');

  if (tab === 'overview') {
    let d;
    try {
      d = await Api.get('/admin/overview');
    } catch (err) {
      UI.toast(err.message, 'error');
      return;
    }
    const dist = [
      ['待接单', d.orders.pending], ['已接单', d.orders.accepted], ['已取件', d.orders.picked],
      ['已送达', d.orders.delivered], ['已完成', d.orders.completed], ['已取消', d.orders.cancelled],
    ];
    const max = Math.max(...dist.map((x) => x[1]), 1);
    body.innerHTML = `
      <div class="stat-grid mb-16 view-enter">
        ${UI.statTile('用户总数', UI.compact(d.users.total), `今日新增 ${d.users.todayNew}`)}
        ${UI.statTile('学生用户', UI.compact(d.users.students), '需求方')}
        ${UI.statTile('跑腿员', UI.compact(d.users.couriers), '服务方')}
        ${UI.statTile('订单总数', UI.compact(d.orders.total), `今日新增 ${d.orders.todayNew}`)}
      </div>
      <div class="stat-grid mb-16 view-enter">
        ${UI.statTile('已完成订单', UI.compact(d.orders.completed), '确认收货并结算')}
        ${UI.statTile('累计交易额', UI.yuan(d.gmv), '已完成订单合计')}
        ${UI.statTile('托管中金额', UI.yuan(d.frozen), '未结算订单托管')}
        ${UI.statTile('完成率', d.orders.total ? `${Math.round((d.orders.completed / d.orders.total) * 100)}` : '0', '已完成 / 全部订单', '%')}
      </div>
      <div class="card card-pad view-enter">
        <div class="card-title">订单状态分布</div>
        <div class="card-sub">各状态订单数量对比（单系列）</div>
        <div class="bar-chart">
          ${dist.map(([label, v]) => `
            <div class="bar-row" title="${UI.esc(label)}：${v} 单">
              <div class="bar-label">${UI.esc(label)}</div>
              <div class="bar-track">
                <div class="bar-fill" style="width:${Math.max((v / max) * 100, v > 0 ? 2 : 0)}%"></div>
              </div>
              <div class="bar-value">${v}</div>
            </div>`).join('')}
        </div>
        <p class="chart-caption">数值标注于条形末端，完整订单数据见「订单监管」表格。</p>
      </div>`;
    return;
  }

  if (tab === 'users') {
    const state = { page: 1, q: '' };
    const loadUsers = async () => {
      body.innerHTML = `<div class="page-loading"><div class="spinner"></div></div>`;
      let data;
      try {
        const qs = new URLSearchParams({ page: state.page, pageSize: 12 });
        if (state.q) qs.set('q', state.q);
        data = await Api.get(`/admin/users?${qs}`);
      } catch (err) {
        UI.toast(err.message, 'error');
        data = { list: [], total: 0, page: 1, pageSize: 12 };
      }
      body.innerHTML = `
        <div class="filter-bar view-enter">
          <input class="input search" id="userSearch" placeholder="🔍 搜索用户名 / 昵称 / 手机号…" value="${UI.esc(state.q)}" />
        </div>
        <div class="table-wrap view-enter">
          <table class="table">
            <thead><tr><th>ID</th><th>用户</th><th>身份</th><th>手机</th><th class="num">余额</th><th class="num">发布 / 完成</th><th>状态</th><th>操作</th></tr></thead>
            <tbody>
              ${data.list.map((u) => `
                <tr>
                  <td class="muted">${u.id}</td>
                  <td>
                    <div class="flex-center">
                      ${UI.avatarHtml(u.nickname, u.id, 'sm')}
                      <div><div style="font-weight:600">${UI.esc(u.nickname)}</div><small class="muted">@${UI.esc(u.username)}</small></div>
                    </div>
                  </td>
                  <td><span class="badge badge-role">${UI.ROLE_LABEL[u.role] || u.role}</span></td>
                  <td class="muted">${UI.esc(u.phone) || '—'}</td>
                  <td class="num">${UI.yuan(u.balance)}</td>
                  <td class="num">${u.publishCount} / ${u.serveCount}</td>
                  <td>${u.status === 'active' ? '<span class="badge badge-completed">正常</span>' : '<span class="badge badge-expired">已禁用</span>'}</td>
                  <td>
                    <div class="actions">
                      <a class="btn btn-ghost btn-sm" href="#/user/${u.id}">查看</a>
                      ${u.id === user.id ? '<span class="muted" style="font-size:12px">当前账号</span>'
                        : u.status === 'active'
                          ? `<button class="btn btn-danger btn-sm js-ban" data-id="${u.id}">禁用</button>`
                          : `<button class="btn btn-success btn-sm js-unban" data-id="${u.id}">恢复</button>`}
                    </div>
                  </td>
                </tr>`).join('') || `<tr><td colspan="8" style="text-align:center;color:var(--ink-3);padding:32px">没有匹配的用户</td></tr>`}
            </tbody>
          </table>
        </div>
        <div class="card-pad">${UI.pagination(data.page, data.pageSize, data.total)}</div>`;

      let debounce = null;
      body.querySelector('#userSearch').addEventListener('input', (e) => {
        clearTimeout(debounce);
        debounce = setTimeout(() => {
          state.q = e.target.value.trim();
          state.page = 1;
          loadUsers();
        }, 400);
      });
      body.querySelectorAll('.page-btn').forEach((b) =>
        b.addEventListener('click', () => {
          state.page = Number(b.dataset.page);
          loadUsers();
        })
      );
      const toggle = (selector, status, msg) => {
        body.querySelectorAll(selector).forEach((btn) =>
          btn.addEventListener('click', async () => {
            if (!(await UI.confirmBox(msg, { danger: status === 'banned', title: '请确认' }))) return;
            try {
              await Api.put(`/admin/users/${btn.dataset.id}/status`, { status });
              UI.toast('操作成功', 'success');
              loadUsers();
            } catch (err) {
              UI.toast(err.message, 'error');
            }
          })
        );
      };
      toggle('.js-ban', 'banned', '禁用后该用户将无法登录和接单，确定禁用吗？');
      toggle('.js-unban', 'active', '确定恢复该用户的正常使用吗？');
    };
    await loadUsers();
    return;
  }

  // 订单监管
  const state = { page: 1, q: '', status: '' };
  const loadOrders = async () => {
    body.innerHTML = `<div class="page-loading"><div class="spinner"></div></div>`;
    let data;
    try {
      const qs = new URLSearchParams({ page: state.page, pageSize: 12 });
      if (state.q) qs.set('q', state.q);
      if (state.status) qs.set('status', state.status);
      data = await Api.get(`/admin/orders?${qs}`);
    } catch (err) {
      UI.toast(err.message, 'error');
      data = { list: [], total: 0, page: 1, pageSize: 12 };
    }
    body.innerHTML = `
      <div class="filter-bar view-enter">
        <input class="input search" id="orderSearch" placeholder="🔍 搜索订单号 / 快递 / 用户…" value="${UI.esc(state.q)}" />
        <select class="select" id="orderStatus">
          <option value="">全部状态</option>
          ${Object.entries(UI.STATUS).map(([k, v]) => `<option value="${k}" ${state.status === k ? 'selected' : ''}>${v.label}</option>`).join('')}
        </select>
      </div>
      <div class="table-wrap view-enter">
        <table class="table">
          <thead><tr><th>订单号</th><th>快递</th><th>发布人 → 跑腿员</th><th class="num">金额</th><th>状态</th><th>创建时间</th><th>操作</th></tr></thead>
          <tbody>
            ${data.list.map((o) => `
              <tr>
                <td><a class="text-primary" href="#/order/${o.id}" style="font-weight:600">${UI.esc(o.orderNo)}</a></td>
                <td>${UI.esc(o.expressCompany)}<br /><small class="muted">${UI.esc(o.pickupPoint)} → ${UI.esc(o.deliveryAddress)}</small></td>
                <td>${UI.esc(o.publisherName)} → ${UI.esc(o.courierName) || '<span class="muted">未接单</span>'}</td>
                <td class="num">${UI.yuan(o.fee + o.tip)}</td>
                <td>${UI.statusBadge(o.status)}</td>
                <td class="muted">${UI.fmtTime(o.createdAt)}</td>
                <td>
                  <div class="actions">
                    <a class="btn btn-ghost btn-sm" href="#/order/${o.id}">详情</a>
                    ${['pending', 'accepted', 'picked', 'delivered'].includes(o.status)
                      ? `<button class="btn btn-danger btn-sm js-force" data-id="${o.id}">强制取消</button>` : ''}
                  </div>
                </td>
              </tr>`).join('') || `<tr><td colspan="7" style="text-align:center;color:var(--ink-3);padding:32px">没有匹配的订单</td></tr>`}
          </tbody>
        </table>
      </div>
      <div class="card-pad">${UI.pagination(data.page, data.pageSize, data.total)}</div>`;

    let debounce = null;
    body.querySelector('#orderSearch').addEventListener('input', (e) => {
      clearTimeout(debounce);
      debounce = setTimeout(() => {
        state.q = e.target.value.trim();
        state.page = 1;
        loadOrders();
      }, 400);
    });
    body.querySelector('#orderStatus').addEventListener('change', (e) => {
      state.status = e.target.value;
      state.page = 1;
      loadOrders();
    });
    body.querySelectorAll('.page-btn').forEach((b) =>
      b.addEventListener('click', () => {
        state.page = Number(b.dataset.page);
        loadOrders();
      })
    );
    body.querySelectorAll('.js-force').forEach((btn) =>
      btn.addEventListener('click', async () => {
        let reason = '';
        const ok = await new Promise((resolve) => {
          UI.openModal({
            title: '强制取消订单',
            body: `<p style="color:var(--ink-2);font-size:13.5px;margin-bottom:12px">托管金额将全额退回发布人，双方都会收到通知。请填写处理原因：</p>
                   <textarea class="textarea" id="forceReason" placeholder="如：虚假订单 / 用户投诉成立" maxlength="100"></textarea>`,
            footer: `<button class="btn btn-ghost" id="forceNo">返回</button>
                     <button class="btn btn-danger" id="forceYes">确认取消</button>`,
          });
          document.getElementById('forceNo').onclick = () => {
            UI.closeModal();
            resolve(false);
          };
          document.getElementById('forceYes').onclick = () => {
            reason = document.getElementById('forceReason').value.trim();
            UI.closeModal();
            resolve(true);
          };
        });
        if (!ok) return;
        try {
          await Api.post(`/admin/orders/${btn.dataset.id}/force-cancel`, { reason: reason || '管理员介入处理' });
          UI.toast('已强制取消并退款', 'success');
          loadOrders();
        } catch (err) {
          UI.toast(err.message, 'error');
        }
      })
    );
  };
  await loadOrders();
};
