'use strict';
/**
 * API 封装：统一鉴权、错误处理与登录态管理
 */
const Api = (() => {
  const TOKEN_KEY = 'cx_token';
  const USER_KEY = 'cx_user';

  const getToken = () => localStorage.getItem(TOKEN_KEY) || '';
  const getUser = () => {
    try {
      return JSON.parse(localStorage.getItem(USER_KEY) || 'null');
    } catch (_) {
      return null;
    }
  };
  const saveAuth = (token, user) => {
    localStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem(USER_KEY, JSON.stringify(user));
  };
  const updateUser = (user) => localStorage.setItem(USER_KEY, JSON.stringify(user));
  const clearAuth = () => {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
  };

  async function request(method, path, body) {
    const headers = { 'Content-Type': 'application/json' };
    const token = getToken();
    if (token) headers['Authorization'] = `Bearer ${token}`;
    let res;
    try {
      res = await fetch(`/api${path}`, {
        method,
        headers,
        body: body === undefined ? undefined : JSON.stringify(body),
      });
    } catch (_) {
      throw new Error('网络连接异常，请稍后重试');
    }
    let json;
    try {
      json = await res.json();
    } catch (_) {
      throw new Error('服务响应异常');
    }
    if (res.status === 401) {
      clearAuth();
      if (!location.hash.startsWith('#/login')) location.hash = '#/login';
      throw new Error(json.message || '登录已过期，请重新登录');
    }
    if (!json.success) throw new Error(json.message || '请求失败');
    return json.data;
  }

  return {
    getToken,
    getUser,
    saveAuth,
    updateUser,
    clearAuth,
    get: (path) => request('GET', path),
    post: (path, body) => request('POST', path, body || {}),
    put: (path, body) => request('PUT', path, body || {}),
  };
})();
