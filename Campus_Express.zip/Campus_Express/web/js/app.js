'use strict';
/**
 * 应用入口：哈希路由、顶部导航、登录态守卫
 */
(() => {
  const app = document.getElementById('app');

  // ============================== 顶部导航 ==============================
  function renderHeader() {
    const user = Api.getUser();
    const nav = document.getElementById('mainNav');
    const right = document.getElementById('headerRight');
    const hash = location.hash || '#/';
    const active = (prefix) => (hash === prefix || hash.startsWith(prefix + '/') ? 'active' : '');

    nav.innerHTML = user
      ? `
        <a class="nav-link ${active('#/board')}" href="#/board"><span class="nav-emoji">🛍️</span>任务大厅</a>
        <a class="nav-link ${active('#/publish')}" href="#/publish"><span class="nav-emoji">📮</span>发布任务</a>
        <a class="nav-link ${active('#/orders')}" href="#/orders"><span class="nav-emoji">📋</span>我的订单</a>
        <a class="nav-link ${active('#/wallet')}" href="#/wallet"><span class="nav-emoji">💰</span>钱包</a>
        <a class="nav-link ${active('#/messages')}" href="#/messages"><span class="nav-emoji">🔔</span>消息</a>
        ${user.role === 'admin' ? `<a class="nav-link ${active('#/admin')}" href="#/admin"><span class="nav-emoji">⚙️</span>管理</a>` : ''}`
      : `
        <a class="nav-link ${active('#/')}" href="#/">首页</a>
        <a class="nav-link" href="#/login">任务大厅</a>`;

    right.innerHTML = user
      ? `
        <a class="balance-chip" href="#/wallet">💰 ¥<span id="headerBalance">${UI.money(user.balance)}</span></a>
        <a class="icon-btn" href="#/messages" title="消息中心">
          🔔<span class="icon-badge" id="unreadBadge" style="display:none">0</span>
        </a>
        <div class="user-menu">
          <button class="user-trigger" id="userTrigger">
            ${UI.avatarHtml(user.nickname, user.id)}
            <span style="font-weight:600;font-size:13px">${UI.esc(user.nickname)}</span>
            <span class="caret">▼</span>
          </button>
          <div class="dropdown" id="userDropdown">
            <div class="dropdown-head">
              <strong>${UI.esc(user.nickname)}</strong>
              <small>${UI.ROLE_LABEL[user.role] || user.role} · @${UI.esc(user.username)}</small>
            </div>
            <a class="dropdown-item" href="#/me">👤 个人中心</a>
            <a class="dropdown-item" href="#/wallet">💰 我的钱包</a>
            ${user.role === 'admin' ? '<a class="dropdown-item" href="#/admin">⚙️ 管理后台</a>' : ''}
            <button class="dropdown-item danger" id="logoutBtn">🚪 退出登录</button>
          </div>
        </div>`
      : `
        <a class="btn btn-ghost btn-sm" href="#/login">登录</a>
        <a class="btn btn-primary btn-sm" href="#/register">免费注册</a>`;

    if (user) {
      const trigger = document.getElementById('userTrigger');
      const dropdown = document.getElementById('userDropdown');
      trigger.addEventListener('click', (e) => {
        e.stopPropagation();
        dropdown.classList.toggle('open');
      });
      document.getElementById('logoutBtn').addEventListener('click', () => {
        Api.clearAuth();
        UI.toast('已退出登录', 'info');
        renderHeader();
        location.hash = '#/';
      });
      refreshHeaderBadges();
    }
  }

  /** 刷新未读数与余额（不阻塞页面） */
  async function refreshHeaderBadges() {
    const user = Api.getUser();
    if (!user) return;
    try {
      const [me, notif] = await Promise.all([Api.get('/me'), Api.get('/notifications?pageSize=1')]);
      Api.updateUser(me);
      const balanceEl = document.getElementById('headerBalance');
      if (balanceEl) balanceEl.textContent = UI.money(me.balance);
      const badge = document.getElementById('unreadBadge');
      if (badge) {
        badge.textContent = notif.unread > 99 ? '99+' : notif.unread;
        badge.style.display = notif.unread > 0 ? '' : 'none';
      }
    } catch (_) {
      /* 静默失败 */
    }
  }
  window.renderHeader = renderHeader;
  window.refreshHeaderBadges = refreshHeaderBadges;

  // ============================== 路由表 ==============================
  const routes = [
    { match: (h) => h === '' || h === '#/' || h === '#', view: 'home' },
    { match: (h) => h === '#/login', view: 'login', guestOnly: true },
    { match: (h) => h === '#/register', view: 'register', guestOnly: true },
    { match: (h) => h === '#/board', view: 'board', auth: true },
    { match: (h) => h === '#/publish', view: 'publish', auth: true },
    { match: (h) => h === '#/orders', view: 'orders', auth: true },
    { match: (h) => h === '#/wallet', view: 'wallet', auth: true },
    { match: (h) => h === '#/messages', view: 'messages', auth: true },
    { match: (h) => h === '#/me', view: 'me', auth: true },
    {
      match: (h) => /^#\/order\/\d+$/.test(h),
      view: 'orderDetail',
      auth: true,
      params: (h) => ({ id: h.split('/')[2] }),
    },
    {
      match: (h) => /^#\/user\/\d+$/.test(h),
      view: 'user',
      auth: true,
      params: (h) => ({ id: h.split('/')[2] }),
    },
    {
      match: (h) => h === '#/admin' || h.startsWith('#/admin/'),
      view: 'admin',
      auth: true,
      params: (h) => ({ tab: h.split('/')[2] || 'overview' }),
    },
  ];

  async function route() {
    const hash = location.hash || '#/';
    const user = Api.getUser();
    renderHeader();

    // 移动端收起菜单
    document.getElementById('mainNav').classList.remove('open');

    const entry = routes.find((r) => r.match(hash));
    if (!entry) {
      app.innerHTML = `
        <div class="empty view-enter">
          <div class="empty-emoji">🧭</div>
          <h3>页面不存在</h3>
          <p>你访问的地址还没有对应的页面</p>
          <a class="btn btn-primary" href="#/">返回首页</a>
        </div>`;
      return;
    }

    if (entry.auth && !Api.getToken()) {
      UI.toast('请先登录后再访问', 'info');
      location.hash = '#/login';
      return;
    }
    if (entry.guestOnly && user) {
      location.hash = '#/board';
      return;
    }

    const params = entry.params ? entry.params(hash) : {};
    const viewFn = Views[entry.view];
    if (!viewFn) return;

    app.innerHTML = `<div class="page-loading"><div class="spinner"></div><p>加载中…</p></div>`;
    try {
      await viewFn(app, params);
    } catch (err) {
      console.error(err);
      app.innerHTML = `
        <div class="empty view-enter">
          <div class="empty-emoji">⚠️</div>
          <h3>加载失败</h3>
          <p>${UI.esc(err.message || '发生未知错误')}</p>
          <button class="btn btn-primary" onclick="location.reload()">重新加载</button>
        </div>`;
    }
    window.scrollTo({ top: 0 });
  }

  // ============================== 启动 ==============================
  // 点击页面任意位置收起用户下拉菜单
  document.addEventListener('click', () => {
    document.querySelectorAll('.dropdown.open').forEach((d) => d.classList.remove('open'));
  });
  document.getElementById('navToggle').addEventListener('click', () => {
    document.getElementById('mainNav').classList.toggle('open');
  });
  window.addEventListener('hashchange', route);

  if (!location.hash) location.hash = '#/';
  route();
})();
