'use strict';
/**
 * UI 工具：转义、格式化、徽章、头像、Toast、Modal、分页
 */
const UI = (() => {
  // ---------- 文本与格式 ----------
  const esc = (s) =>
    String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  /** 分 → 元字符串（不带 ¥） */
  const money = (fen) => (Number(fen || 0) / 100).toFixed(2);
  /** 分 → 带 ¥ 的金额 */
  const yuan = (fen) => `¥${money(fen)}`;
  /** 大数字紧凑显示（统计磁贴用）：1,284 / 12.9K / 3.2M */
  const compact = (n) => {
    n = Number(n || 0);
    if (n >= 1e6) return `${(n / 1e6).toFixed(1).replace(/\.0$/, '')}M`;
    if (n >= 1e4) return `${(n / 1e4).toFixed(1).replace(/\.0$/, '')}K`;
    return n.toLocaleString('en-US');
  };

  /** "2026-10-27 18:20:41" → "2026-10-27 18:20" */
  const fmtTime = (s) => {
    if (!s) return '—';
    return String(s).slice(0, 16);
  };
  /** 相对时间 */
  const timeAgo = (s) => {
    if (!s) return '';
    const t = new Date(String(s).replace(/-/g, '/')).getTime();
    const diff = Date.now() - t;
    if (Number.isNaN(t)) return s;
    if (diff < 60 * 1000) return '刚刚';
    if (diff < 60 * 60 * 1000) return `${Math.floor(diff / 60000)} 分钟前`;
    if (diff < 24 * 60 * 60 * 1000) return `${Math.floor(diff / 3600000)} 小时前`;
    if (diff < 30 * 24 * 60 * 60 * 1000) return `${Math.floor(diff / 86400000)} 天前`;
    return fmtTime(s);
  };

  // ---------- 订单状态 ----------
  const STATUS = {
    pending: { label: '待接单', cls: 'badge-pending' },
    accepted: { label: '已接单', cls: 'badge-accepted' },
    picked: { label: '已取件', cls: 'badge-picked' },
    delivered: { label: '已送达', cls: 'badge-delivered' },
    completed: { label: '已完成', cls: 'badge-completed' },
    cancelled: { label: '已取消', cls: 'badge-cancelled' },
    expired: { label: '已超时', cls: 'badge-expired' },
  };
  const statusBadge = (status) => {
    const s = STATUS[status] || { label: status, cls: 'badge-cancelled' };
    return `<span class="badge ${s.cls}">${s.label}</span>`;
  };

  const SIZE_LABEL = { small: '小件', medium: '中件', large: '大件' };
  const ROLE_LABEL = { student: '学生', courier: '跑腿员', admin: '管理员' };
  const TX_LABEL = {
    recharge: { label: '充值', cls: 'badge-completed' },
    withdraw: { label: '提现', cls: 'badge-cancelled' },
    escrow_freeze: { label: '托管冻结', cls: 'badge-pending' },
    escrow_release: { label: '结算到账', cls: 'badge-completed' },
    escrow_refund: { label: '退款', cls: 'badge-accepted' },
  };

  // ---------- 头像 ----------
  const AVATAR_COLORS = ['#4f46e5', '#7c3aed', '#2563eb', '#0891b2', '#0d9488', '#d97706', '#db2777', '#e11d48', '#65a30d', '#9333ea'];
  const avatarHtml = (name, id = 0, size = '') => {
    const ch = String(name || '?').trim().charAt(0).toUpperCase();
    const color = AVATAR_COLORS[Math.abs(Number(id) || 0) % AVATAR_COLORS.length];
    return `<span class="avatar ${size}" style="background:${color}">${esc(ch)}</span>`;
  };

  // ---------- Toast ----------
  let toastTimer = null;
  function toast(message, type = 'info') {
    const root = document.getElementById('toastRoot');
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    const icon = type === 'success' ? '✅' : type === 'error' ? '⚠️' : 'ℹ️';
    el.innerHTML = `<span>${icon}</span><span>${esc(message)}</span>`;
    root.appendChild(el);
    setTimeout(() => {
      el.style.opacity = '0';
      el.style.transform = 'translateX(16px)';
      el.style.transition = 'all 0.25s ease';
      setTimeout(() => el.remove(), 260);
    }, 3000);
  }

  // ---------- Modal ----------
  function openModal({ title, body, wide = false, footer = '' }) {
    closeModal();
    const root = document.getElementById('modalRoot');
    root.innerHTML = `
      <div class="modal-mask" id="modalMask">
        <div class="modal-card ${wide ? 'wide' : ''}">
          <div class="modal-title">${esc(title)}</div>
          <div class="modal-body">${body}</div>
          ${footer ? `<div class="modal-foot">${footer}</div>` : ''}
        </div>
      </div>`;
    document.getElementById('modalMask').addEventListener('click', (e) => {
      if (e.target.id === 'modalMask') closeModal();
    });
  }
  function closeModal() {
    const root = document.getElementById('modalRoot');
    if (root) root.innerHTML = '';
  }
  /** 确认弹窗，返回 Promise<boolean> */
  function confirmBox(message, { okText = '确定', danger = false, title = '请确认' } = {}) {
    return new Promise((resolve) => {
      openModal({
        title,
        body: `<p style="color:var(--ink-2);font-size:14px;">${esc(message)}</p>`,
        footer: `
          <button class="btn btn-ghost" id="confirmCancel">取消</button>
          <button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" id="confirmOk">${esc(okText)}</button>`,
      });
      document.getElementById('confirmCancel').onclick = () => {
        closeModal();
        resolve(false);
      };
      document.getElementById('confirmOk').onclick = () => {
        closeModal();
        resolve(true);
      };
    });
  }

  // ---------- 分页 ----------
  function pagination(page, pageSize, total) {
    const pages = Math.max(1, Math.ceil(total / pageSize));
    if (pages <= 1) return '';
    const btn = (p, label = p, active = false, disabled = false) =>
      `<button class="page-btn ${active ? 'active' : ''}" data-page="${p}" ${disabled ? 'disabled' : ''}>${label}</button>`;
    let html = `<div class="pagination">`;
    html += btn(page - 1, '‹', false, page <= 1);
    const win = [];
    for (let p = 1; p <= pages; p++) {
      if (p === 1 || p === pages || Math.abs(p - page) <= 2) win.push(p);
      else if (win[win.length - 1] !== '…') win.push('…');
    }
    for (const p of win) html += p === '…' ? `<span class="page-info">…</span>` : btn(p, p, p === page);
    html += btn(page + 1, '›', false, page >= pages);
    html += `<span class="page-info">共 ${total} 条</span></div>`;
    return html;
  }

  // ---------- 统计磁贴 ----------
  /** label: 句式短语（无尾冒号）· value: 主数字 · note: 辅助说明 */
  function statTile(label, value, note = '', unit = '') {
    return `
      <div class="stat-tile">
        <div class="stat-label">${esc(label)}</div>
        <div class="stat-value">${esc(String(value))}${unit ? `<span class="unit">${esc(unit)}</span>` : ''}</div>
        ${note ? `<div class="stat-note">${esc(note)}</div>` : ''}
      </div>`;
  }

  return {
    esc, money, yuan, compact, fmtTime, timeAgo,
    STATUS, statusBadge, SIZE_LABEL, ROLE_LABEL, TX_LABEL,
    avatarHtml, toast, openModal, closeModal, confirmBox,
    pagination, statTile,
  };
})();
