'use strict';
/**
 * 视图：发布任务 / 我的订单 / 订单详情
 */

// ================================ 发布任务 ================================
Views.publish = async (container) => {
  const user = Api.getUser();
  let balance = user ? user.balance : 0;
  try {
    const me = await Api.get('/me');
    balance = me.balance;
    Api.updateUser(me);
  } catch (_) {
    /* 使用缓存余额 */
  }

  container.innerHTML = `
  <div class="page-head view-enter">
    <div>
      <h1>发布代取任务</h1>
      <p class="page-desc">填写快递信息，跑腿员接单后为你送达宿舍</p>
    </div>
  </div>
  <div class="detail-grid view-enter">
    <div class="card card-pad">
      <form id="publishForm">
        <div class="form-row">
          <div class="field">
            <label>快递公司<span class="req">*</span></label>
            <input class="input" name="expressCompany" list="expressList" placeholder="如：顺丰速运" required />
            <datalist id="expressList">
              <option value="顺丰速运"></option><option value="中通快递"></option>
              <option value="圆通速递"></option><option value="韵达快递"></option>
              <option value="申通快递"></option><option value="京东物流"></option>
              <option value="极兔速递"></option><option value="邮政EMS"></option>
            </datalist>
          </div>
          <div class="field">
            <label>取件码 / 运单号<span class="req">*</span></label>
            <input class="input" name="trackingNo" placeholder="如：SF1234567890" required />
          </div>
        </div>
        <div class="form-row">
          <div class="field">
            <label>取件地点<span class="req">*</span></label>
            <input class="input" name="pickupPoint" list="pickupList" placeholder="如：东区菜鸟驿站" required />
            <datalist id="pickupList">
              <option value="东区菜鸟驿站"></option><option value="西区快递中心"></option>
              <option value="北区京东站点"></option><option value="南区韵达驿站"></option>
              <option value="校门口邮政所"></option>
            </datalist>
          </div>
          <div class="field">
            <label>送达地址<span class="req">*</span></label>
            <input class="input" name="deliveryAddress" placeholder="如：3号宿舍楼 512" required />
          </div>
        </div>
        <div class="field">
          <label>物品描述</label>
          <input class="input" name="itemDesc" placeholder="选填，如：一箱零食 / 文件袋（易碎）" maxlength="200" />
        </div>
        <div class="field">
          <label>物品大小<span class="req">*</span></label>
          <div class="chip-group" id="sizeChips">
            <button type="button" class="chip-option" data-size="small" data-fee="300">📦 小件（书本文件）</button>
            <button type="button" class="chip-option selected" data-size="medium" data-fee="500">📦📦 中件（日用品）</button>
            <button type="button" class="chip-option" data-size="large" data-fee="700">📦📦📦 大件（较重物品）</button>
          </div>
        </div>
        <div class="form-row">
          <div class="field">
            <label>代取费（元）<span class="req">*</span></label>
            <div class="chip-group mb-8" id="feeChips">
              <button type="button" class="chip-option" data-fee="300">¥3</button>
              <button type="button" class="chip-option selected" data-fee="500">¥5</button>
              <button type="button" class="chip-option" data-fee="600">¥6</button>
              <button type="button" class="chip-option" data-fee="800">¥8</button>
              <button type="button" class="chip-option" data-fee="1000">¥10</button>
            </div>
            <input class="input" name="feeYuan" type="number" min="1" max="200" step="0.01" value="5" required />
            <p class="hint">建议 ¥3 ~ ¥8，大件或远距离可适当提高</p>
          </div>
          <div class="field">
            <label>加急小费（元）</label>
            <div class="chip-group mb-8" id="tipChips">
              <button type="button" class="chip-option selected" data-tip="0">不加急</button>
              <button type="button" class="chip-option" data-tip="100">¥1</button>
              <button type="button" class="chip-option" data-tip="200">¥2</button>
              <button type="button" class="chip-option" data-tip="500">¥5</button>
            </div>
            <input class="input" name="tipYuan" type="number" min="0" max="100" step="0.01" value="0" />
            <p class="hint">小费全额给跑腿员，加急任务接单更快</p>
          </div>
        </div>
        <div class="form-row">
          <div class="field">
            <label>期望送达时间</label>
            <input class="input" name="deadline" type="datetime-local" />
            <p class="hint">超过该时间未接单将自动取消并全额退款</p>
          </div>
          <div class="field">
            <label>备注</label>
            <input class="input" name="remark" placeholder="选填，如：到了请电话联系" maxlength="200" />
          </div>
        </div>
      </form>
    </div>

    <div class="card card-pad" style="position:sticky;top:84px">
      <div class="card-title">费用明细</div>
      <div class="card-sub">资金由平台托管，安全有保障</div>
      <div class="flex-between mb-8"><span class="muted">基础代取费</span><strong id="sumFee">¥5.00</strong></div>
      <div class="flex-between mb-8"><span class="muted">加急小费</span><strong id="sumTip">¥0.00</strong></div>
      <div class="divider"></div>
      <div class="flex-between mb-8"><span>合计支付</span><strong class="text-primary" style="font-size:22px" id="sumTotal">¥5.00</strong></div>
      <div class="flex-between mb-8"><span class="muted">当前余额</span><span id="sumBalance">¥${UI.money(balance)}</span></div>
      <div class="flex-between mb-16"><span class="muted">支付后剩余</span><span id="sumLeft">¥${UI.money(balance - 500)}</span></div>
      <button class="btn btn-primary btn-block btn-lg" id="submitBtn">🚀 发布任务</button>
      <p class="hint mt-8">💡 发布后代取费将被冻结托管；跑腿员送达、你确认收货后才结算给对方。取消订单可全额退款。</p>
    </div>
  </div>`;

  const form = container.querySelector('#publishForm');
  const feeInput = form.feeYuan;
  const tipInput = form.tipYuan;

  function currentCents(input) {
    const v = Number(input.value);
    return Number.isFinite(v) ? Math.round(v * 100) : 0;
  }
  function refreshSummary() {
    const fee = currentCents(feeInput);
    const tip = currentCents(tipInput);
    container.querySelector('#sumFee').textContent = `¥${UI.money(fee)}`;
    container.querySelector('#sumTip').textContent = `¥${UI.money(tip)}`;
    container.querySelector('#sumTotal').textContent = `¥${UI.money(fee + tip)}`;
    container.querySelector('#sumLeft').textContent = `¥${UI.money(balance - fee - tip)}`;
    container.querySelector('#sumLeft').className = balance - fee - tip < 0 ? 'text-danger' : '';
  }

  // 芯片选择器
  function bindChips(id, { field, attr, allowNone }) {
    const wrap = container.querySelector(id);
    wrap.querySelectorAll('.chip-option').forEach((chip) => {
      chip.addEventListener('click', () => {
        wrap.querySelectorAll('.chip-option').forEach((c) => c.classList.remove('selected'));
        chip.classList.add('selected');
        if (field) {
          const cents = Number(chip.dataset[attr]);
          field.value = (cents / 100).toFixed(cents % 100 === 0 ? 0 : 2);
          refreshSummary();
        }
      });
    });
    if (field) {
      field.addEventListener('input', () => {
        const val = String(field.value);
        wrap.querySelectorAll('.chip-option').forEach((c) => {
          const cents = Number(c.dataset[attr]);
          c.classList.toggle('selected', (cents / 100).toFixed(2) === Number(val).toFixed(2));
        });
        refreshSummary();
      });
    }
    void allowNone;
  }
  container.querySelectorAll('#sizeChips .chip-option').forEach((chip) => {
    chip.addEventListener('click', () => {
      container.querySelectorAll('#sizeChips .chip-option').forEach((c) => c.classList.remove('selected'));
      chip.classList.add('selected');
      // 按大小给出代取费建议
      const cents = Number(chip.dataset.fee);
      feeInput.value = (cents / 100).toFixed(0);
      container.querySelectorAll('#feeChips .chip-option').forEach((c) =>
        c.classList.toggle('selected', Number(c.dataset.fee) === cents)
      );
      refreshSummary();
    });
  });
  bindChips('#feeChips', { field: feeInput, attr: 'fee' });
  bindChips('#tipChips', { field: tipInput, attr: 'tip' });
  feeInput.addEventListener('input', refreshSummary);
  tipInput.addEventListener('input', refreshSummary);
  refreshSummary();

  container.querySelector('#submitBtn').addEventListener('click', async () => {
    const fd = new FormData(form);
    const fee = currentCents(feeInput);
    const tip = currentCents(tipInput);
    if (fee < 100 || fee > 20000) {
      UI.toast('代取费需在 ¥1 ~ ¥200 之间', 'error');
      return;
    }
    if (tip < 0 || tip > 10000) {
      UI.toast('加急小费需在 ¥0 ~ ¥100 之间', 'error');
      return;
    }
    const sizeEl = container.querySelector('#sizeChips .chip-option.selected');
    const btn = container.querySelector('#submitBtn');
    btn.disabled = true;
    btn.textContent = '发布中…';
    try {
      const order = await Api.post('/orders', {
        expressCompany: fd.get('expressCompany'),
        trackingNo: fd.get('trackingNo'),
        pickupPoint: fd.get('pickupPoint'),
        deliveryAddress: fd.get('deliveryAddress'),
        itemDesc: fd.get('itemDesc') || '',
        size: sizeEl ? sizeEl.dataset.size : 'medium',
        fee,
        tip,
        deadline: fd.get('deadline') || '',
        remark: fd.get('remark') || '',
      });
      UI.toast('任务发布成功，等待跑腿员接单！', 'success');
      location.hash = `#/order/${order.id}`;
    } catch (err) {
      UI.toast(err.message, 'error');
      btn.disabled = false;
      btn.textContent = '🚀 发布任务';
    }
  });
};

// ================================ 我的订单 ================================
Views.orders = async (container) => {
  const state = { scope: 'mine', status: '', page: 1 };
  const STATUS_CHIPS = [
    ['', '全部'], ['pending', '待接单'], ['accepted', '已接单'], ['picked', '已取件'],
    ['delivered', '已送达'], ['completed', '已完成'], ['cancelled', '已取消'], ['expired', '已超时'],
  ];

  async function load() {
    container.innerHTML = `<div class="page-loading"><div class="spinner"></div><p>加载订单中…</p></div>`;
    let data;
    try {
      const qs = new URLSearchParams({ scope: state.scope, page: state.page, pageSize: 10 });
      if (state.status) qs.set('status', state.status);
      data = await Api.get(`/orders?${qs}`);
    } catch (err) {
      UI.toast(err.message, 'error');
      data = { list: [], total: 0, page: 1, pageSize: 10 };
    }
    const user = Api.getUser();

    const actionsFor = (o) => {
      const btns = [];
      if (state.scope === 'mine') {
        if (['pending', 'accepted'].includes(o.status)) btns.push(`<button class="btn btn-danger btn-sm js-cancel" data-id="${o.id}">取消订单</button>`);
        if (o.status === 'delivered') btns.push(`<button class="btn btn-success btn-sm js-complete" data-id="${o.id}">确认收货</button>`);
        if (o.status === 'completed' && !o.rating) btns.push(`<a class="btn btn-soft btn-sm" href="#/order/${o.id}">去评价</a>`);
      } else {
        if (o.status === 'accepted') {
          btns.push(`<button class="btn btn-primary btn-sm js-pickup" data-id="${o.id}">✅ 取件</button>`);
          btns.push(`<button class="btn btn-ghost btn-sm js-abandon" data-id="${o.id}">撤单</button>`);
        }
        if (o.status === 'picked') btns.push(`<button class="btn btn-primary btn-sm js-deliver" data-id="${o.id}">🚚 送达</button>`);
        if (o.status === 'delivered') btns.push(`<span class="muted" style="font-size:12px">等待用户确认</span>`);
      }
      return btns.join('');
    };

    const cards = data.list
      .map((o) => `
        <article class="order-card" data-id="${o.id}">
          <div class="oc-head">
            <div>
              <div class="oc-company">${UI.esc(o.expressCompany)} <span class="tag">${UI.SIZE_LABEL[o.size] || o.size}</span></div>
              <div class="oc-no">订单号 ${UI.esc(o.orderNo)}</div>
            </div>
            ${UI.statusBadge(o.status)}
          </div>
          <div class="oc-route">
            <span class="place">📍 ${UI.esc(o.pickupPoint)}</span>
            <span class="arrow">➜</span>
            <span class="place">🏠 ${UI.esc(o.deliveryAddress)}</span>
          </div>
          ${o.itemDesc ? `<div class="oc-item">📦 ${UI.esc(o.itemDesc)}</div>` : ''}
          ${o.cancelReason ? `<div class="oc-item" style="background:var(--danger-soft);color:var(--danger-text)">✕ ${UI.esc(o.cancelReason)}</div>` : ''}
          <div class="oc-foot">
            <div>
              <div class="oc-fee"><span class="yuan">¥</span>${UI.money(o.totalAmount)}</div>
              <div class="oc-meta">
                ${state.scope === 'mine'
                  ? (o.courierName ? `跑腿员：${UI.esc(o.courierName)}` : '等待跑腿员接单')
                  : `发布人：${UI.esc(o.publisherName)}`} · ${UI.timeAgo(o.createdAt)}
              </div>
            </div>
            <div class="flex-center">${actionsFor(o)}</div>
          </div>
        </article>`)
      .join('');

    container.innerHTML = `
      <div class="page-head view-enter">
        <div>
          <h1>我的订单</h1>
          <p class="page-desc">管理你发布的代取任务和你接下的跑腿单</p>
        </div>
        <div class="page-actions">
          <a class="btn btn-primary" href="#/publish">📮 发布新任务</a>
        </div>
      </div>
      <div class="tabs view-enter">
        <button class="tab ${state.scope === 'mine' ? 'active' : ''}" data-scope="mine">📮 我发布的</button>
        <button class="tab ${state.scope === 'taken' ? 'active' : ''}" data-scope="taken">🛵 我接的单</button>
      </div>
      <div class="filter-bar view-enter">
        ${STATUS_CHIPS.map(([val, label]) =>
          `<button class="chip-option ${state.status === val ? 'selected' : ''}" data-status="${val}">${label}</button>`).join('')}
      </div>
      ${data.list.length
        ? `<div class="order-grid view-enter">${cards}</div>${UI.pagination(data.page, data.pageSize, data.total)}`
        : `<div class="empty view-enter">
             <div class="empty-emoji">🗂️</div>
             <h3>这里还没有订单</h3>
             <p>${state.scope === 'mine' ? '发布第一个代取任务试试吧' : '去任务大厅看看有什么单可以接'}</p>
             <a class="btn btn-primary" href="${state.scope === 'mine' ? '#/publish' : '#/board'}">${state.scope === 'mine' ? '发布代取任务' : '逛逛任务大厅'}</a>
           </div>`}`;

    container.querySelectorAll('.tab').forEach((t) =>
      t.addEventListener('click', () => {
        state.scope = t.dataset.scope;
        state.page = 1;
        load();
      })
    );
    container.querySelectorAll('.filter-bar .chip-option').forEach((c) =>
      c.addEventListener('click', () => {
        state.status = c.dataset.status;
        state.page = 1;
        load();
      })
    );
    container.querySelectorAll('.page-btn').forEach((b) =>
      b.addEventListener('click', () => {
        state.page = Number(b.dataset.page);
        load();
      })
    );
    container.querySelectorAll('.order-card').forEach((card) =>
      card.addEventListener('click', (e) => {
        if (e.target.closest('button') || e.target.closest('a')) return;
        location.hash = `#/order/${card.dataset.id}`;
      })
    );

    // 快捷操作：fn 返回 false 表示用户放弃操作，不刷新不提示
    const act = async (selector, fn, confirmMsg) => {
      container.querySelectorAll(selector).forEach((btn) =>
        btn.addEventListener('click', async (e) => {
          e.stopPropagation();
          if (confirmMsg && !(await UI.confirmBox(confirmMsg, { title: '请确认', danger: selector.includes('cancel') }))) return;
          btn.disabled = true;
          try {
            const result = await fn(btn.dataset.id);
            if (result === false) {
              btn.disabled = false;
              return;
            }
            UI.toast('操作成功', 'success');
            window.refreshHeaderBadges && window.refreshHeaderBadges();
            load();
          } catch (err) {
            UI.toast(err.message, 'error');
            btn.disabled = false;
          }
        })
      );
    };
    act('.js-complete', (id) => Api.post(`/orders/${id}/complete`), '确认已收到快递？托管资金将结算给跑腿员。');
    act('.js-cancel', (id) => cancelModal(id), null);
    act('.js-pickup', (id) => Api.post(`/orders/${id}/pickup`), '确认已取到快递？');
    act('.js-deliver', (id) => Api.post(`/orders/${id}/deliver`), '确认快递已送达指定地点？');
    act('.js-abandon', (id) => Api.post(`/orders/${id}/abandon`), '确定撤单吗？订单将重新开放给其他跑腿员。');

    async function cancelModal(id) {
      let reason = '';
      const ok = await new Promise((resolve) => {
        UI.openModal({
          title: '取消订单',
          body: `<p style="color:var(--ink-2);font-size:13.5px;margin-bottom:12px">取消后代取费将全额退回余额。请告诉我们取消原因：</p>
                 <textarea class="textarea" id="cancelReason" placeholder="如：自己顺路取回 / 不需要了" maxlength="100"></textarea>`,
          footer: `<button class="btn btn-ghost" id="cancelNo">再想想</button>
                   <button class="btn btn-danger" id="cancelYes">确认取消</button>`,
        });
        document.getElementById('cancelNo').onclick = () => {
          UI.closeModal();
          resolve(false);
        };
        document.getElementById('cancelYes').onclick = () => {
          reason = document.getElementById('cancelReason').value.trim();
          UI.closeModal();
          resolve(true);
        };
      });
      if (!ok) return false;
      await Api.post(`/orders/${id}/cancel`, { reason });
      return true;
    }
    void user;
  }

  await load();
};

// ================================ 订单详情 ================================
Views.orderDetail = async (container, params) => {
  const user = Api.getUser();
  let o;
  try {
    o = await Api.get(`/orders/${params.id}`);
  } catch (err) {
    container.innerHTML = `<div class="empty view-enter"><div class="empty-emoji">😕</div><h3>订单不存在</h3><p>${UI.esc(err.message)}</p><a class="btn btn-primary" href="#/board">返回任务大厅</a></div>`;
    return;
  }

  const isPublisher = user.id === o.publisherId;
  const isCourier = user.id === o.courierId;
  const isAdmin = user.role === 'admin';

  const steps = [
    { key: 'created', title: '需求发布', time: o.createdAt },
    { key: 'accepted', title: '跑腿接单', time: o.acceptedAt },
    { key: 'picked', title: '驿站取件', time: o.pickedAt },
    { key: 'delivered', title: '送达宿舍', time: o.deliveredAt },
    { key: 'completed', title: '确认收货', time: o.completedAt },
  ];
  const order = ['pending', 'accepted', 'picked', 'delivered', 'completed'];
  const progressIdx = order.indexOf(o.status);
  const timelineHtml = steps
    .map((s, i) => {
      const done = !!s.time;
      const current = !done && i === progressIdx + 1 && progressIdx >= 0;
      return `
        <div class="tl-item ${done ? 'done' : current ? 'current' : ''}">
          <div class="tl-dot"></div>
          <div class="tl-title ${done ? '' : 'tl-pending-text'}">${s.title}</div>
          <div class="tl-time">${done ? UI.fmtTime(s.time) : '待完成'}</div>
        </div>`;
    })
    .join('');

  const stars = (n) => '★'.repeat(n) + '☆'.repeat(5 - n);

  const actionBtns = [];
  if (user.role === 'courier' && o.status === 'pending' && !isPublisher) {
    actionBtns.push(`<button class="btn btn-primary btn-lg js-accept">🛵 立即接单</button>`);
  }
  if (isCourier && o.status === 'accepted') {
    actionBtns.push(`<button class="btn btn-primary btn-lg js-pickup">✅ 我已取件</button>`);
    actionBtns.push(`<button class="btn btn-ghost js-abandon">取消接单</button>`);
  }
  if (isCourier && o.status === 'picked') {
    actionBtns.push(`<button class="btn btn-primary btn-lg js-deliver">🚚 我已送达</button>`);
  }
  if (isPublisher && o.status === 'delivered') {
    actionBtns.push(`<button class="btn btn-success btn-lg js-complete">🎉 确认收货</button>`);
  }
  if ((isPublisher || isAdmin) && ['pending', 'accepted'].includes(o.status)) {
    actionBtns.push(`<button class="btn btn-danger js-cancel">${isAdmin && !isPublisher ? '强制取消订单' : '取消订单'}</button>`);
  }

  container.innerHTML = `
  <div class="page-head view-enter">
    <div>
      <h1>订单详情</h1>
      <p class="page-desc">订单号 ${UI.esc(o.orderNo)} · 发布于 ${UI.fmtTime(o.createdAt)}</p>
    </div>
    <div class="page-actions">${UI.statusBadge(o.status)}</div>
  </div>

  ${o.status === 'cancelled' || o.status === 'expired'
    ? `<div class="card card-pad mb-16 view-enter" style="border-left:3px solid var(--danger)">
         <strong class="text-danger">订单已${o.status === 'expired' ? '超时自动取消' : '取消'}</strong>
         <p class="muted mt-8">原因：${UI.esc(o.cancelReason || '—')} · 托管金额 ¥${UI.money(o.totalAmount)} 已退回发布人余额</p>
       </div>`
    : ''}

  <div class="detail-grid view-enter">
    <div style="display:flex;flex-direction:column;gap:16px">
      <div class="card card-pad">
        <div class="card-title">快递信息</div>
        <div class="card-sub">${UI.esc(o.expressCompany)} · ${UI.SIZE_LABEL[o.size] || o.size}</div>
        <div class="info-grid">
          <div class="info-item">
            <div class="info-label">取件码 / 运单号</div>
            <div class="info-value">
              ${o.trackingNoMasked
                ? `<span class="track-code">${UI.esc(o.trackingNo)} <button type="button" class="js-reveal">接单后可见</button></span>`
                : `<span class="track-code">${UI.esc(o.trackingNo)}</span>`}
            </div>
          </div>
          <div class="info-item">
            <div class="info-label">期望送达</div>
            <div class="info-value">${o.deadline ? UI.fmtTime(o.deadline) : '不限'}</div>
          </div>
          <div class="info-item">
            <div class="info-label">取件地点</div>
            <div class="info-value">📍 ${UI.esc(o.pickupPoint)}</div>
          </div>
          <div class="info-item">
            <div class="info-label">送达地址</div>
            <div class="info-value">🏠 ${UI.esc(o.deliveryAddress)}</div>
          </div>
          ${o.itemDesc ? `<div class="info-item wide"><div class="info-label">物品描述</div><div class="info-value">📦 ${UI.esc(o.itemDesc)}</div></div>` : ''}
          ${o.remark ? `<div class="info-item wide"><div class="info-label">备注</div><div class="info-value">💬 ${UI.esc(o.remark)}</div></div>` : ''}
        </div>
      </div>

      <div class="card card-pad">
        <div class="card-title">订单进度</div>
        <div class="card-sub">每个节点都会向双方推送站内消息</div>
        <div class="timeline">${timelineHtml}</div>
      </div>

      ${o.status === 'completed' && o.rating
        ? `<div class="card card-pad">
             <div class="card-title">用户评价</div>
             <div class="review-box">
               <div class="review-stars">${stars(o.rating)} <span class="muted" style="letter-spacing:0">${o.rating}.0 分</span></div>
               ${o.review ? `<div class="review-text">${UI.esc(o.review)}</div>` : '<div class="review-text muted">用户未填写文字评价</div>'}
               <div class="muted mt-8" style="font-size:12px">${UI.esc(o.publisherName)} · ${UI.fmtTime(o.reviewedAt)}</div>
             </div>
           </div>`
        : ''}
      ${o.status === 'completed' && !o.rating && isPublisher
        ? `<div class="card card-pad" id="reviewCard">
             <div class="card-title">评价跑腿员</div>
             <div class="card-sub">你的评价会帮助更多同学找到靠谱的跑腿员</div>
             <div class="chip-group mb-8" id="starChips">
               ${[1, 2, 3, 4, 5].map((n) => `<button type="button" class="chip-option ${n === 5 ? 'selected' : ''}" data-star="${n}">${n} 星</button>`).join('')}
             </div>
             <textarea class="textarea" id="reviewText" placeholder="说说这次服务的体验吧（选填）" maxlength="200"></textarea>
             <button class="btn btn-primary mt-16 js-review">提交评价</button>
           </div>`
        : ''}
    </div>

    <div style="display:flex;flex-direction:column;gap:16px">
      <div class="card card-pad">
        <div class="card-title">费用明细</div>
        <div class="flex-between mb-8"><span class="muted">基础代取费</span><strong>¥${UI.money(o.fee)}</strong></div>
        <div class="flex-between mb-8"><span class="muted">加急小费</span><strong>¥${UI.money(o.tip)}</strong></div>
        <div class="divider"></div>
        <div class="flex-between mb-8"><span>合计</span><strong class="text-primary" style="font-size:20px">¥${UI.money(o.totalAmount)}</strong></div>
        <p class="hint">${o.status === 'completed' ? '✅ 已结算给跑腿员' : o.status === 'cancelled' || o.status === 'expired' ? '↩️ 已全额退回发布人' : '🔒 平台托管中，确认收货后结算'}</p>
      </div>

      <div class="card card-pad">
        <div class="card-title">相关用户</div>
        <div class="flex-between mb-16">
          <div class="flex-center">
            ${UI.avatarHtml(o.publisherName, o.publisherId)}
            <div><div style="font-weight:600">${UI.esc(o.publisherName)}</div><small class="muted">发布人</small></div>
          </div>
          <a class="btn btn-ghost btn-sm" href="#/user/${o.publisherId}">主页</a>
        </div>
        ${o.courierName
          ? `<div class="flex-between">
              <div class="flex-center">
                ${UI.avatarHtml(o.courierName, o.courierId)}
                <div><div style="font-weight:600">${UI.esc(o.courierName)}</div><small class="muted">跑腿员</small></div>
              </div>
              <a class="btn btn-ghost btn-sm" href="#/user/${o.courierId}">主页</a>
            </div>`
          : `<p class="muted">🛵 暂无跑腿员接单</p>`}
      </div>

      ${actionBtns.length
        ? `<div class="card card-pad">
             <div class="card-title">可执行操作</div>
             <div class="action-bar mt-16">${actionBtns.join('')}</div>
           </div>`
        : ''}
    </div>
  </div>`;

  // ---------- 事件 ----------
  const run = async (fn, confirmMsg, okText) => {
    if (confirmMsg && !(await UI.confirmBox(confirmMsg, { title: '请确认', okText }))) return;
    try {
      await fn();
      UI.toast('操作成功', 'success');
      window.refreshHeaderBadges && window.refreshHeaderBadges();
      Views.orderDetail(container, params);
    } catch (err) {
      UI.toast(err.message, 'error');
    }
  };

  container.querySelector('.js-accept')?.addEventListener('click', () =>
    run(() => Api.post(`/orders/${o.id}/accept`), '确定接下这个代取任务吗？', '接单'));
  container.querySelector('.js-pickup')?.addEventListener('click', () =>
    run(() => Api.post(`/orders/${o.id}/pickup`), '确认已经取到快递？', '确认取件'));
  container.querySelector('.js-deliver')?.addEventListener('click', () =>
    run(() => Api.post(`/orders/${o.id}/deliver`), '确认快递已送达指定地点？', '确认送达'));
  container.querySelector('.js-complete')?.addEventListener('click', () =>
    run(() => Api.post(`/orders/${o.id}/complete`), '确认已收到快递？托管资金将结算给跑腿员。', '确认收货'));
  container.querySelector('.js-abandon')?.addEventListener('click', () =>
    run(() => Api.post(`/orders/${o.id}/abandon`), '确定撤单吗？订单将重新开放给其他跑腿员。', '撤单'));

  container.querySelector('.js-cancel')?.addEventListener('click', async () => {
    let reason = '';
    const ok = await new Promise((resolve) => {
      UI.openModal({
        title: isAdmin && !isPublisher ? '强制取消订单' : '取消订单',
        body: `<p style="color:var(--ink-2);font-size:13.5px;margin-bottom:12px">取消后托管金额 ¥${UI.money(o.totalAmount)} 将全额退回发布人余额。请填写原因：</p>
               <textarea class="textarea" id="cancelReason" placeholder="如：自己顺路取回 / 不需要了" maxlength="100"></textarea>`,
        footer: `<button class="btn btn-ghost" id="cancelNo">再想想</button>
                 <button class="btn btn-danger" id="cancelYes">确认取消</button>`,
      });
      document.getElementById('cancelNo').onclick = () => {
        UI.closeModal();
        resolve(false);
      };
      document.getElementById('cancelYes').onclick = () => {
        reason = document.getElementById('cancelReason').value.trim();
        UI.closeModal();
        resolve(true);
      };
    });
    if (!ok) return;
    try {
      if (isAdmin && !isPublisher) await Api.post(`/admin/orders/${o.id}/force-cancel`, { reason: reason || '管理员介入处理' });
      else await Api.post(`/orders/${o.id}/cancel`, { reason });
      UI.toast('订单已取消，退款已退回余额', 'success');
      window.refreshHeaderBadges && window.refreshHeaderBadges();
      Views.orderDetail(container, params);
    } catch (err) {
      UI.toast(err.message, 'error');
    }
  });

  // 评价
  const reviewCard = container.querySelector('#reviewCard');
  if (reviewCard) {
    let starsVal = 5;
    reviewCard.querySelectorAll('#starChips .chip-option').forEach((chip) => {
      chip.addEventListener('click', () => {
        reviewCard.querySelectorAll('#starChips .chip-option').forEach((c) => c.classList.remove('selected'));
        chip.classList.add('selected');
        starsVal = Number(chip.dataset.star);
      });
    });
    reviewCard.querySelector('.js-review').addEventListener('click', async () => {
      try {
        await Api.post(`/orders/${o.id}/review`, {
          rating: starsVal,
          content: reviewCard.querySelector('#reviewText').value.trim(),
        });
        UI.toast('感谢你的评价！', 'success');
        Views.orderDetail(container, params);
      } catch (err) {
        UI.toast(err.message, 'error');
      }
    });
  }

  container.querySelector('.js-reveal')?.addEventListener('click', () => {
    UI.toast('接单后才能查看完整取件码', 'info');
  });
};
