'use strict';
/**
 * 视图：落地页 / 登录 / 注册 / 任务大厅
 */
window.Views = window.Views || {};

// ================================ 落地页 ================================
Views.home = async (container) => {
  const user = Api.getUser();
  let stats = { users: 0, couriers: 0, completedOrders: 0, avgRating: 5 };
  try {
    stats = await Api.get('/stats/public');
  } catch (_) {
    /* 展示默认值 */
  }

  container.innerHTML = `
  <section class="hero view-enter">
    <div class="hero-inner">
      <div class="hero-eyebrow">🎓 面向全校师生的互助平台</div>
      <h1>取快递这件小事<br />交给<span class="grad-text">校园代取</span></h1>
      <p class="hero-sub">发布代取需求，跑腿员极速接单。资金托管担保交易，实时消息追踪进度，让每一份快递都准时抵达你的宿舍。</p>
      <div class="hero-cta">
        ${user
          ? `<a class="btn btn-primary btn-lg" href="#/board">🛍️ 进入任务大厅</a>
             <a class="btn btn-ghost btn-lg" href="#/publish">📮 发布代取任务</a>`
          : `<a class="btn btn-primary btn-lg" href="#/register">🚀 免费注册，立即使用</a>
             <a class="btn btn-ghost btn-lg" href="#/login">已有账号，直接登录</a>`}
      </div>
    </div>
  </section>

  <section class="stat-grid view-enter mb-24">
    ${UI.statTile('注册用户', UI.compact(stats.users), '覆盖全校各学院')}
    ${UI.statTile('完成订单', UI.compact(stats.completedOrders), '每一次托付都已送达')}
    ${UI.statTile('活跃跑腿员', UI.compact(stats.couriers), '随时待命，极速响应')}
    ${UI.statTile('平均评分', stats.avgRating, '来自真实用户的服务评价', ' 分')}
  </section>

  <section class="feature-grid view-enter">
    <div class="feature-card">
      <div class="f-icon" style="background:var(--primary-soft)">🚀</div>
      <h3>极速接单</h3>
      <p>发布需求后全校跑腿员实时可见，智能匹配顺路订单，几分钟内就有人接单。</p>
    </div>
    <div class="feature-card">
      <div class="f-icon" style="background:var(--success-soft)">🛡️</div>
      <h3>资金托管</h3>
      <p>代取费由平台冻结托管，确认收货后才结算给跑腿员，取消订单自动全额退款。</p>
    </div>
    <div class="feature-card">
      <div class="f-icon" style="background:var(--accent-soft)">📍</div>
      <h3>全程可追</h3>
      <p>接单、取件、送达每个节点实时推送站内消息，订单进度一目了然。</p>
    </div>
    <div class="feature-card">
      <div class="f-icon" style="background:#ede9fe">⭐</div>
      <h3>信用评价</h3>
      <p>双向评价机制，服务越好接单越快，构建互帮互助的校园生活生态。</p>
    </div>
  </section>

  <section class="how-section view-enter">
    <h2>四步完成，轻松代取</h2>
    <p class="how-sub">从发布到收货，全流程线上化</p>
    <div class="how-steps">
      <div class="how-step"><div class="step-num">1</div><h4>发布需求</h4><p>填写快递单号、取件点和宿舍地址</p></div>
      <div class="how-step"><div class="step-num">2</div><h4>跑腿接单</h4><p>跑腿员接单后前往驿站取件</p></div>
      <div class="how-step"><div class="step-num">3</div><h4>送达确认</h4><p>核对取件码，收到快递后确认收货</p></div>
      <div class="how-step"><div class="step-num">4</div><h4>评价结算</h4><p>为服务打分，托管资金自动结算</p></div>
    </div>
  </section>`;
};

// ================================ 登录 ================================
Views.login = async (container) => {
  container.innerHTML = `
  <div class="auth-wrap view-enter">
    <div class="auth-card">
      <h2 class="auth-title">欢迎回来 👋</h2>
      <p class="auth-sub">登录校园快递代取平台，继续你的校园生活</p>
      <form id="loginForm">
        <div class="field">
          <label>用户名<span class="req">*</span></label>
          <input class="input" name="username" placeholder="请输入用户名" autocomplete="username" required />
        </div>
        <div class="field">
          <label>密码<span class="req">*</span></label>
          <input class="input" name="password" type="password" placeholder="请输入密码" autocomplete="current-password" required />
        </div>
        <button class="btn btn-primary btn-block btn-lg" type="submit">登 录</button>
      </form>
      <p class="auth-switch">还没有账号？<a href="#/register">立即注册</a></p>
      <div class="divider"></div>
      <p class="auth-switch" style="margin-top:0">演示账号：xiaoming / 123456（学生） · paotui1 / 123456（跑腿员） · admin / admin123（管理员）</p>
    </div>
  </div>`;

  container.querySelector('#loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const btn = e.target.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.textContent = '登录中…';
    try {
      const data = await Api.post('/auth/login', {
        username: fd.get('username'),
        password: fd.get('password'),
      });
      Api.saveAuth(data.token, data.user);
      UI.toast(`欢迎回来，${data.user.nickname}！`, 'success');
      window.renderHeader();
      location.hash = '#/board';
    } catch (err) {
      UI.toast(err.message, 'error');
      btn.disabled = false;
      btn.textContent = '登 录';
    }
  });
};

// ================================ 注册 ================================
Views.register = async (container) => {
  let role = 'student';
  container.innerHTML = `
  <div class="auth-wrap view-enter" style="max-width:520px">
    <div class="auth-card">
      <h2 class="auth-title">创建账号 🎉</h2>
      <p class="auth-sub">选择你的身份，开启校园代取之旅</p>
      <div class="role-cards">
        <div class="role-card selected" data-role="student">
          <span class="role-emoji">🎒</span>
          <strong>我是学生</strong>
          <small>发布代取需求</small>
        </div>
        <div class="role-card" data-role="courier">
          <span class="role-emoji">🛵</span>
          <strong>我是跑腿员</strong>
          <small>接单赚零花钱</small>
        </div>
      </div>
      <form id="registerForm">
        <div class="form-row">
          <div class="field">
            <label>用户名<span class="req">*</span></label>
            <input class="input" name="username" placeholder="3-20 位字母数字下划线" required />
          </div>
          <div class="field">
            <label>昵称<span class="req">*</span></label>
            <input class="input" name="nickname" placeholder="展示给他人的名字" required />
          </div>
        </div>
        <div class="form-row">
          <div class="field">
            <label>密码<span class="req">*</span></label>
            <input class="input" name="password" type="password" placeholder="至少 6 位" required />
          </div>
          <div class="field">
            <label>确认密码<span class="req">*</span></label>
            <input class="input" name="password2" type="password" placeholder="再次输入密码" required />
          </div>
        </div>
        <div class="form-row">
          <div class="field">
            <label>手机号</label>
            <input class="input" name="phone" placeholder="选填，方便联系" maxlength="11" />
          </div>
          <div class="field">
            <label>宿舍 / 地址</label>
            <input class="input" name="dorm" placeholder="如：3号宿舍楼 512" />
          </div>
        </div>
        <button class="btn btn-primary btn-block btn-lg" type="submit">注 册</button>
      </form>
      <p class="auth-switch">已有账号？<a href="#/login">直接登录</a></p>
    </div>
  </div>`;

  container.querySelectorAll('.role-card').forEach((card) => {
    card.addEventListener('click', () => {
      container.querySelectorAll('.role-card').forEach((c) => c.classList.remove('selected'));
      card.classList.add('selected');
      role = card.dataset.role;
    });
  });

  container.querySelector('#registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const password = String(fd.get('password') || '');
    if (password !== String(fd.get('password2') || '')) {
      UI.toast('两次输入的密码不一致', 'error');
      return;
    }
    const btn = e.target.querySelector('button[type="submit"]');
    btn.disabled = true;
    try {
      const data = await Api.post('/auth/register', {
        username: fd.get('username'),
        password,
        nickname: fd.get('nickname'),
        role,
        phone: fd.get('phone') || '',
        dorm: fd.get('dorm') || '',
      });
      Api.saveAuth(data.token, data.user);
      UI.toast('注册成功，欢迎加入！', 'success');
      window.renderHeader();
      location.hash = '#/board';
    } catch (err) {
      UI.toast(err.message, 'error');
      btn.disabled = false;
    }
  });
};

// ================================ 任务大厅 ================================
Views.board = async (container) => {
  const state = { page: 1, q: '', size: '', sort: 'latest' };

  async function load() {
    container.innerHTML = `<div class="page-loading"><div class="spinner"></div><p>加载任务中…</p></div>`;
    let data;
    try {
      const qs = new URLSearchParams({ scope: 'board', page: state.page, pageSize: 12, sort: state.sort });
      if (state.q) qs.set('q', state.q);
      if (state.size) qs.set('size', state.size);
      data = await Api.get(`/orders?${qs}`);
    } catch (err) {
      UI.toast(err.message, 'error');
      data = { list: [], total: 0, page: 1, pageSize: 12 };
    }

    const cards = data.list
      .map((o) => `
        <article class="order-card" data-id="${o.id}">
          <div class="oc-head">
            <div>
              <div class="oc-company">${UI.esc(o.expressCompany)} <span class="tag">${UI.SIZE_LABEL[o.size] || o.size}</span></div>
              <div class="oc-no">订单号 ${UI.esc(o.orderNo)}</div>
            </div>
            ${UI.statusBadge(o.status)}
          </div>
          <div class="oc-route">
            <span class="place">📍 ${UI.esc(o.pickupPoint)}</span>
            <span class="arrow">➜</span>
            <span class="place">🏠 ${UI.esc(o.deliveryAddress)}</span>
          </div>
          ${o.itemDesc ? `<div class="oc-item">📦 ${UI.esc(o.itemDesc)}</div>` : ''}
          <div class="oc-foot">
            <div>
              <div class="oc-fee"><span class="yuan">¥</span>${UI.money(o.totalAmount)}${o.tip > 0 ? `<span class="tip">含加急小费 ¥${UI.money(o.tip)}</span>` : ''}</div>
              <div class="oc-meta">${UI.esc(o.publisherName)} 发布 · ${UI.timeAgo(o.createdAt)}${o.deadline ? ` · ⏰ ${UI.esc(o.deadline.slice(5, 16))} 前送达` : ''}</div>
            </div>
            <button class="btn btn-primary btn-sm js-accept" data-id="${o.id}">立即接单</button>
          </div>
        </article>`)
      .join('');

    container.innerHTML = `
      <div class="page-head view-enter">
        <div>
          <h1>任务大厅</h1>
          <p class="page-desc">浏览同学们发布的代取需求，接单赚取零花钱</p>
        </div>
        <div class="page-actions">
          <a class="btn btn-ghost" href="#/orders">📋 我的订单</a>
          <a class="btn btn-primary" href="#/publish">📮 发布代取任务</a>
        </div>
      </div>
      <div class="filter-bar view-enter">
        <input class="input search" id="searchInput" placeholder="🔍 搜索快递公司 / 取件点 / 订单号…" value="${UI.esc(state.q)}" />
        <span class="filter-label">大小</span>
        <select class="select" id="sizeFilter">
          <option value="">全部</option>
          <option value="small" ${state.size === 'small' ? 'selected' : ''}>小件</option>
          <option value="medium" ${state.size === 'medium' ? 'selected' : ''}>中件</option>
          <option value="large" ${state.size === 'large' ? 'selected' : ''}>大件</option>
        </select>
        <span class="filter-label">排序</span>
        <select class="select" id="sortFilter">
          <option value="latest" ${state.sort === 'latest' ? 'selected' : ''}>最新发布</option>
          <option value="fee_desc" ${state.sort === 'fee_desc' ? 'selected' : ''}>佣金从高到低</option>
          <option value="fee_asc" ${state.sort === 'fee_asc' ? 'selected' : ''}>佣金从低到高</option>
          <option value="deadline" ${state.sort === 'deadline' ? 'selected' : ''}>最急优先</option>
        </select>
      </div>
      ${data.list.length
        ? `<div class="order-grid view-enter">${cards}</div>${UI.pagination(data.page, data.pageSize, data.total)}`
        : `<div class="empty view-enter">
             <div class="empty-emoji">🛵</div>
             <h3>暂时没有待接单的任务</h3>
             <p>休息一下，或者发布你自己的代取需求吧</p>
             <a class="btn btn-primary" href="#/publish">发布代取任务</a>
           </div>`}`;

    // 事件绑定
    const searchInput = container.querySelector('#searchInput');
    let debounce = null;
    searchInput.addEventListener('input', () => {
      clearTimeout(debounce);
      debounce = setTimeout(() => {
        state.q = searchInput.value.trim();
        state.page = 1;
        load();
      }, 400);
    });
    container.querySelector('#sizeFilter').addEventListener('change', (e) => {
      state.size = e.target.value;
      state.page = 1;
      load();
    });
    container.querySelector('#sortFilter').addEventListener('change', (e) => {
      state.sort = e.target.value;
      state.page = 1;
      load();
    });
    container.querySelectorAll('.page-btn').forEach((b) => {
      b.addEventListener('click', () => {
        state.page = Number(b.dataset.page);
        load();
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    });
    container.querySelectorAll('.order-card').forEach((card) => {
      card.addEventListener('click', (e) => {
        if (e.target.closest('.js-accept')) return;
        location.hash = `#/order/${card.dataset.id}`;
      });
    });
    container.querySelectorAll('.js-accept').forEach((btn) => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const ok = await UI.confirmBox('确定接下这个代取任务吗？接单后请尽快取件配送。', { title: '确认接单', okText: '接单' });
        if (!ok) return;
        btn.disabled = true;
        btn.textContent = '接单中…';
        try {
          await Api.post(`/orders/${btn.dataset.id}/accept`);
          UI.toast('接单成功，请尽快取件！', 'success');
          location.hash = `#/order/${btn.dataset.id}`;
        } catch (err) {
          UI.toast(err.message, 'error');
          btn.disabled = false;
          btn.textContent = '立即接单';
        }
      });
    });
  }

  await load();
};
