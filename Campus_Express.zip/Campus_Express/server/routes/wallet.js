'use strict';
/**
 * 钱包路由：余额 / 充值 / 提现 / 流水
 */
const { db, withTx, addTransaction } = require('../db');
const { pickInt, paginate } = require('../util');

const TX_SELECT = `
  SELECT t.id, t.type, t.amount, t.balance_after AS balanceAfter, t.order_id AS orderId,
         t.note, t.created_at AS createdAt, o.order_no AS orderNo
  FROM transactions t
  LEFT JOIN orders o ON o.id = t.order_id
`;

function getWallet({ query, user }) {
  const { page, pageSize, offset } = paginate(query, 20, 50);
  const total = db.prepare('SELECT COUNT(*) AS n FROM transactions WHERE user_id = ?').get(user.id).n;
  const list = db
    .prepare(`${TX_SELECT} WHERE t.user_id = ? ORDER BY t.created_at DESC, t.id DESC LIMIT ? OFFSET ?`)
    .all(user.id, pageSize, offset);
  return { balance: user.balance, list, total, page, pageSize };
}

/** 充值（模拟支付通道，直接到账） */
function recharge({ body, user }) {
  const amount = pickInt(body, 'amount', { min: 100, max: 1000000, label: '充值金额' });
  return withTx(() => {
    const balance = addTransaction(user.id, 'recharge', amount, null, '充值');
    return { balance, amount };
  });
}

/** 提现（即时扣除余额，实际平台需对接支付通道打款） */
function withdraw({ body, user }) {
  const amount = pickInt(body, 'amount', { min: 100, max: 1000000, label: '提现金额' });
  return withTx(() => {
    const balance = addTransaction(user.id, 'withdraw', -amount, null, '提现');
    return { balance, amount };
  });
}

module.exports = [
  { method: 'GET', path: '/api/wallet', auth: true, handler: getWallet },
  { method: 'POST', path: '/api/wallet/recharge', auth: true, handler: recharge },
  { method: 'POST', path: '/api/wallet/withdraw', auth: true, handler: withdraw },
];
