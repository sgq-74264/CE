'use strict';
/**
 * 订单路由：任务大厅 / 发布 / 状态机流转 / 评价 / 统计
 *
 * 状态机（严格单向 + 可回退的接单取消）：
 *   pending ──accept──▶ accepted ──pickup──▶ picked ──deliver──▶ delivered ──complete──▶ completed
 *      │                   │                                                              ▲
 *      ├─cancel/expire─▶ cancelled ◀──cancel──────────────────────────────────────────────┘（accepted 可取消）
 *      └───────────────▶ abandoned（跑腿员撤单后回到 pending）
 */
const { db, withTx, addTransaction, addNotify } = require('../db');
const {
  fail,
  pickStr,
  pickInt,
  pickEnum,
  nowStr,
  normalizeDateTime,
  genOrderNo,
  paginate,
} = require('../util');

const ORDER_SELECT = `
  SELECT o.id, o.order_no AS orderNo, o.publisher_id AS publisherId, o.courier_id AS courierId,
         o.express_company AS expressCompany, o.tracking_no AS trackingNo,
         o.pickup_point AS pickupPoint, o.delivery_address AS deliveryAddress,
         o.item_desc AS itemDesc, o.size, o.fee, o.tip, o.status, o.remark,
         o.cancel_reason AS cancelReason, o.deadline,
         o.created_at AS createdAt, o.accepted_at AS acceptedAt, o.picked_at AS pickedAt,
         o.delivered_at AS deliveredAt, o.completed_at AS completedAt, o.cancelled_at AS cancelledAt,
         o.rating, o.review, o.reviewed_at AS reviewedAt,
         p.nickname AS publisherName, p.role AS publisherRole,
         c.nickname AS courierName, c.role AS courierRole
  FROM orders o
  LEFT JOIN users p ON p.id = o.publisher_id
  LEFT JOIN users c ON c.id = o.courier_id
`;

const maskTracking = (no) => {
  const s = String(no || '');
  if (s.length <= 4) return '****';
  return `${s.slice(0, 2)}****${s.slice(-2)}`;
};

/** 对外输出订单：非参与方（发布人/跑腿员/管理员）看不到真实取件码 */
function present(order, viewer) {
  const totalAmount = order.fee + order.tip;
  const privileged =
    viewer &&
    (viewer.role === 'admin' || viewer.id === order.publisherId || viewer.id === order.courierId);
  return {
    ...order,
    totalAmount,
    trackingNo: privileged ? order.trackingNo : maskTracking(order.trackingNo),
    trackingNoMasked: !privileged,
  };
}

function getOrder(id) {
  return db.prepare(`${ORDER_SELECT} WHERE o.id = ?`).get(id);
}

/** 惰性超时扫描：pending 且超过期望送达时间的订单自动取消并退款 */
function sweepExpired() {
  const now = nowStr();
  const rows = db
    .prepare(
      `SELECT id, order_no AS orderNo, publisher_id AS publisherId, fee, tip
       FROM orders WHERE status = 'pending' AND deadline IS NOT NULL AND deadline < ?`
    )
    .all(now);
  for (const o of rows) {
    try {
      withTx(() => {
        const r = db
          .prepare(
            `UPDATE orders SET status = 'expired', cancelled_at = ?, cancel_reason = ?
             WHERE id = ? AND status = 'pending'`
          )
          .run(now, '超过期望送达时间，系统自动取消', o.id);
        if (!r.changes) return;
        addTransaction(o.publisherId, 'escrow_refund', o.fee + o.tip, o.id, '超时未接单，托管退款');
        addNotify(o.publisherId, 'order', '订单已超时取消', `您的订单（${o.orderNo}）超时无人接单，已自动取消并全额退款。`, o.id);
      });
    } catch (_) {
      /* 单条失败不影响其它订单 */
    }
  }
}

/** 订单列表查询 */
function listOrders({ query, user }) {
  sweepExpired();
  const scope = pickEnum(query, 'scope', ['board', 'mine', 'taken'], { required: false, def: 'board', label: '范围' });
  const { page, pageSize, offset } = paginate(query);
  const q = (query.q || '').trim();
  const sort = pickEnum(query, 'sort', ['latest', 'fee_desc', 'fee_asc', 'deadline'], {
    required: false,
    def: 'latest',
    label: '排序',
  });
  const statusFilter = (query.status || '').trim();
  const sizeFilter = pickEnum(query, 'size', ['small', 'medium', 'large'], {
    required: false,
    def: '',
    label: '物品大小',
  });

  const where = [];
  const args = [];
  const STATUSES = ['pending', 'accepted', 'picked', 'delivered', 'completed', 'cancelled', 'expired'];
  if (scope === 'board') {
    where.push(`o.status = 'pending'`, 'o.publisher_id != ?');
    args.push(user.id);
  } else if (scope === 'mine') {
    where.push('o.publisher_id = ?');
    args.push(user.id);
    if (statusFilter) {
      if (!STATUSES.includes(statusFilter)) fail(400, '订单状态筛选值不合法');
      where.push('o.status = ?');
      args.push(statusFilter);
    }
  } else {
    where.push('o.courier_id = ?');
    args.push(user.id);
    if (statusFilter) {
      if (!STATUSES.includes(statusFilter)) fail(400, '订单状态筛选值不合法');
      where.push('o.status = ?');
      args.push(statusFilter);
    }
  }
  if (sizeFilter) {
    where.push('o.size = ?');
    args.push(sizeFilter);
  }
  if (q) {
    where.push('(o.express_company LIKE ? OR o.tracking_no LIKE ? OR o.pickup_point LIKE ? OR o.delivery_address LIKE ? OR o.item_desc LIKE ? OR o.order_no LIKE ?)');
    for (let i = 0; i < 6; i++) args.push(`%${q}%`);
  }

  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const orderSql = {
    latest: 'ORDER BY o.created_at DESC, o.id DESC',
    fee_desc: 'ORDER BY (o.fee + o.tip) DESC, o.created_at DESC',
    fee_asc: 'ORDER BY (o.fee + o.tip) ASC, o.created_at DESC',
    deadline: 'ORDER BY (o.deadline IS NULL), o.deadline ASC, o.created_at DESC',
  }[sort];

  const total = db.prepare(`SELECT COUNT(*) AS n FROM orders o ${whereSql}`).get(...args).n;
  const list = db.prepare(`${ORDER_SELECT} ${whereSql} ${orderSql} LIMIT ? OFFSET ?`).all(...args, pageSize, offset);
  return { list: list.map((o) => present(o, user)), total, page, pageSize };
}

/** 发布代取订单（资金托管：余额冻结，确认收货后结算给跑腿员） */
function createOrder({ body, user }) {
  const expressCompany = pickStr(body, 'expressCompany', { min: 2, max: 20, label: '快递公司' });
  const trackingNo = pickStr(body, 'trackingNo', { min: 4, max: 32, label: '取件码/运单号' });
  const pickupPoint = pickStr(body, 'pickupPoint', { min: 2, max: 50, label: '取件地点' });
  const deliveryAddress = pickStr(body, 'deliveryAddress', { min: 2, max: 50, label: '送达地址' });
  const itemDesc = pickStr(body, 'itemDesc', { required: false, max: 200, label: '物品描述' });
  const size = pickEnum(body, 'size', ['small', 'medium', 'large'], { required: false, def: 'medium', label: '物品大小' });
  const fee = pickInt(body, 'fee', { min: 100, max: 20000, label: '代取费' });
  const tip = pickInt(body, 'tip', { required: false, min: 0, max: 10000, def: 0, label: '加急小费' });
  const remark = pickStr(body, 'remark', { required: false, max: 200, label: '备注' });

  let deadline = null;
  if (body && body.deadline) {
    deadline = normalizeDateTime(body.deadline, '期望送达时间');
    if (deadline <= nowStr()) fail(400, '期望送达时间必须晚于当前时间');
  }

  const total = fee + tip;
  return withTx(() => {
    const orderNo = genOrderNo();
    const info = db
      .prepare(
        `INSERT INTO orders (order_no, publisher_id, express_company, tracking_no, pickup_point,
           delivery_address, item_desc, size, fee, tip, status, remark, deadline, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?)`
      )
      .run(orderNo, user.id, expressCompany, trackingNo, pickupPoint, deliveryAddress, itemDesc, size, fee, tip, remark, deadline, nowStr());
    const id = Number(info.lastInsertRowid);

    // 托管冻结（记账函数内部带余额条件扣减，不足则抛错并回滚整个事务）
    addTransaction(user.id, 'escrow_freeze', -total, id, '订单托管冻结');

    addNotify(user.id, 'order', '订单发布成功', `订单（${expressCompany} ${trackingNo}）已进入任务大厅，等待跑腿员接单。`, id);
    return present(getOrder(id), user);
  });
}

/** 接单（仅跑腿员，不能接自己的单） */
function acceptOrder({ params, user }) {
  const id = Number(params.id);
  sweepExpired();
  return withTx(() => {
    const order = getOrder(id);
    if (!order) fail(404, '订单不存在');
    if (order.status !== 'pending') fail(409, '该订单已被接单或已关闭');
    if (user.role !== 'courier') fail(403, '只有跑腿员可以接单');
    if (order.publisherId === user.id) fail(400, '不能接受自己发布的订单');

    const r = db
      .prepare(
        `UPDATE orders SET status = 'accepted', courier_id = ?, accepted_at = ?
         WHERE id = ? AND status = 'pending'`
      )
      .run(user.id, nowStr(), id);
    if (!r.changes) fail(409, '手慢了，订单状态已变更');

    addNotify(order.publisherId, 'order', '有跑腿员接单啦', `「${user.nickname}」已接下您的订单（${order.expressCompany} ${order.trackingNo}），正在赶往取件点。`, id);
    addNotify(user.id, 'order', '接单成功', `请尽快前往 ${order.pickupPoint} 取件（${order.expressCompany} ${order.trackingNo}），送往 ${order.deliveryAddress}。`, id);
    return present(getOrder(id), user);
  });
}

/** 取件（仅接单跑腿员） */
function pickupOrder({ params, user }) {
  const id = Number(params.id);
  return withTx(() => {
    const order = getOrder(id);
    if (!order) fail(404, '订单不存在');
    if (order.courierId !== user.id) fail(403, '只有本单跑腿员可以操作');
    const r = db
      .prepare(`UPDATE orders SET status = 'picked', picked_at = ? WHERE id = ? AND status = 'accepted'`)
      .run(nowStr(), id);
    if (!r.changes) fail(409, '当前状态不可取件');
    addNotify(order.publisherId, 'order', '快递已取出', `「${user.nickname}」已取到您的快递，正在配送中，请保持电话畅通。`, id);
    return present(getOrder(id), user);
  });
}

/** 送达（仅接单跑腿员） */
function deliverOrder({ params, user }) {
  const id = Number(params.id);
  return withTx(() => {
    const order = getOrder(id);
    if (!order) fail(404, '订单不存在');
    if (order.courierId !== user.id) fail(403, '只有本单跑腿员可以操作');
    const r = db
      .prepare(`UPDATE orders SET status = 'delivered', delivered_at = ? WHERE id = ? AND status = 'picked'`)
      .run(nowStr(), id);
    if (!r.changes) fail(409, '当前状态不可送达');
    addNotify(order.publisherId, 'order', '快递已送达', `「${user.nickname}」已将快递送至 ${order.deliveryAddress}，请确认收货。`, id);
    return present(getOrder(id), user);
  });
}

/** 确认收货（仅发布人）：托管资金结算给跑腿员 */
function completeOrder({ params, user }) {
  const id = Number(params.id);
  return withTx(() => {
    const order = getOrder(id);
    if (!order) fail(404, '订单不存在');
    if (order.publisherId !== user.id) fail(403, '只有发布人可以确认收货');
    const r = db
      .prepare(`UPDATE orders SET status = 'completed', completed_at = ? WHERE id = ? AND status = 'delivered'`)
      .run(nowStr(), id);
    if (!r.changes) fail(409, '当前状态不可确认收货');

    const total = order.fee + order.tip;
    addTransaction(order.courierId, 'escrow_release', total, id, '订单结算到账');
    addNotify(order.courierId, 'wallet', '订单已结算', `订单（${order.orderNo}）已确认收货，¥${(total / 100).toFixed(2)} 已到账。`, id);
    addNotify(order.publisherId, 'order', '订单已完成', `订单（${order.orderNo}）已完成，欢迎对跑腿员做出评价。`, id);
    return present(getOrder(id), user);
  });
}

/** 取消订单：发布人可在「待接单/已接单」阶段取消，全额退款 */
function cancelOrder({ params, body, user }) {
  const id = Number(params.id);
  const reason = pickStr(body, 'reason', { required: false, max: 100, label: '取消原因' });
  return withTx(() => {
    const order = getOrder(id);
    if (!order) fail(404, '订单不存在');
    const isAdmin = user.role === 'admin';
    if (!isAdmin && order.publisherId !== user.id) fail(403, '只有发布人可以取消订单');
    if (!['pending', 'accepted'].includes(order.status)) {
      fail(409, '快递已取出或已送达，无法取消。如有问题请联系跑腿员或管理员');
    }

    const r = db
      .prepare(
        `UPDATE orders SET status = 'cancelled', cancelled_at = ?, cancel_reason = ?
         WHERE id = ? AND status IN ('pending','accepted')`
      )
      .run(nowStr(), reason || (isAdmin ? '管理员取消' : '发布人取消'), id);
    if (!r.changes) fail(409, '订单状态已变更，取消失败');

    const total = order.fee + order.tip;
    addTransaction(order.publisherId, 'escrow_refund', total, id, '订单取消退款');
    addNotify(order.publisherId, 'wallet', '订单取消退款', `订单（${order.orderNo}）已取消，¥${(total / 100).toFixed(2)} 已退回余额。`, id);
    if (order.courierId) {
      addNotify(order.courierId, 'order', '订单已被取消', `订单（${order.orderNo}）已被发布人取消，请勿继续配送。`, id);
    }
    return present(getOrder(id), user);
  });
}

/** 跑腿员撤单：已接单但未取件可撤，订单回到大厅重新开放 */
function abandonOrder({ params, user }) {
  const id = Number(params.id);
  return withTx(() => {
    const order = getOrder(id);
    if (!order) fail(404, '订单不存在');
    if (order.courierId !== user.id) fail(403, '只有本单跑腿员可以撤单');
    const r = db
      .prepare(
        `UPDATE orders SET status = 'pending', courier_id = NULL, accepted_at = NULL
         WHERE id = ? AND status = 'accepted'`
      )
      .run(id);
    if (!r.changes) fail(409, '已取件后无法撤单，请继续完成配送');
    addNotify(order.publisherId, 'order', '跑腿员已撤单', `「${user.nickname}」取消了接单，订单已重新开放给其他跑腿员。`, id);
    return present(getOrder(id), user);
  });
}

/** 评价（仅发布人，仅已完成订单，只能评一次） */
function reviewOrder({ params, body, user }) {
  const id = Number(params.id);
  const rating = pickInt(body, 'rating', { min: 1, max: 5, label: '评分' });
  const content = pickStr(body, 'content', { required: false, max: 200, label: '评价内容' });
  return withTx(() => {
    const order = getOrder(id);
    if (!order) fail(404, '订单不存在');
    if (order.publisherId !== user.id) fail(403, '只有发布人可以评价');
    if (order.status !== 'completed') fail(409, '订单完成后才能评价');
    const r = db
      .prepare('UPDATE orders SET rating = ?, review = ?, reviewed_at = ? WHERE id = ? AND rating IS NULL')
      .run(rating, content, nowStr(), id);
    if (!r.changes) fail(409, '该订单已评价');
    addNotify(order.courierId, 'order', `收到 ${rating} 星评价`, content ? `「${user.nickname}」评价：${content}` : `「${user.nickname}」给出了 ${rating} 星评价。`, id);
    return present(getOrder(id), user);
  });
}

/** 个人订单统计 */
function myStats({ user }) {
  const pub = db
    .prepare(
      `SELECT COUNT(*) AS published,
              SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS completed,
              SUM(CASE WHEN status IN ('cancelled','expired') THEN 1 ELSE 0 END) AS cancelled,
              SUM(CASE WHEN status = 'completed' THEN fee + tip ELSE 0 END) AS spent,
              SUM(CASE WHEN status IN ('pending','accepted','picked','delivered') THEN fee + tip ELSE 0 END) AS frozen
       FROM orders WHERE publisher_id = ?`
    )
    .get(user.id);
  const taken = db
    .prepare(
      `SELECT COUNT(*) AS taken,
              SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS takenCompleted,
              SUM(CASE WHEN status = 'completed' THEN fee + tip ELSE 0 END) AS earned,
              AVG(CASE WHEN rating IS NOT NULL THEN rating END) AS avgRating,
              COUNT(rating) AS ratingCount
       FROM orders WHERE courier_id = ?`
    )
    .get(user.id);
  return {
    published: pub.published || 0,
    completed: pub.completed || 0,
    cancelled: pub.cancelled || 0,
    spent: pub.spent || 0,
    frozen: pub.frozen || 0,
    taken: taken.taken || 0,
    takenCompleted: taken.takenCompleted || 0,
    earned: taken.earned || 0,
    avgRating: taken.avgRating ? Math.round(taken.avgRating * 10) / 10 : null,
    ratingCount: taken.ratingCount || 0,
  };
}

/** 平台公开统计（落地页展示） */
function publicStats() {
  const users = db.prepare(`SELECT COUNT(*) AS n FROM users WHERE status = 'active'`).get().n;
  const couriers = db.prepare(`SELECT COUNT(*) AS n FROM users WHERE role = 'courier' AND status = 'active'`).get().n;
  const completed = db.prepare(`SELECT COUNT(*) AS n FROM orders WHERE status = 'completed'`).get().n;
  const avg = db.prepare(`SELECT AVG(rating) AS r FROM orders WHERE rating IS NOT NULL`).get().r;
  return { users, couriers, completedOrders: completed, avgRating: avg ? Math.round(avg * 10) / 10 : 5.0 };
}

module.exports = [
  { method: 'GET', path: '/api/orders', auth: true, handler: listOrders },
  { method: 'POST', path: '/api/orders', auth: true, handler: createOrder },
  { method: 'GET', path: '/api/orders/stats', auth: true, handler: myStats },
  { method: 'GET', path: '/api/stats/public', handler: publicStats },
  {
    method: 'GET',
    path: '/api/orders/:id',
    auth: true,
    handler: ({ params, user }) => {
      sweepExpired();
      const order = getOrder(Number(params.id));
      if (!order) fail(404, '订单不存在');
      return present(order, user);
    },
  },
  { method: 'POST', path: '/api/orders/:id/accept', auth: true, handler: acceptOrder },
  { method: 'POST', path: '/api/orders/:id/pickup', auth: true, handler: pickupOrder },
  { method: 'POST', path: '/api/orders/:id/deliver', auth: true, handler: deliverOrder },
  { method: 'POST', path: '/api/orders/:id/complete', auth: true, handler: completeOrder },
  { method: 'POST', path: '/api/orders/:id/cancel', auth: true, handler: cancelOrder },
  { method: 'POST', path: '/api/orders/:id/abandon', auth: true, handler: abandonOrder },
  { method: 'POST', path: '/api/orders/:id/review', auth: true, handler: reviewOrder },
];
