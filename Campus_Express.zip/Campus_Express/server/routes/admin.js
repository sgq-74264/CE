'use strict';
/**
 * 管理后台路由：平台总览 / 用户管理 / 订单监管
 */
const { db, withTx, addTransaction, addNotify } = require('../db');
const { fail, pickStr, pickEnum, paginate, nowStr, toPublicUser } = require('../util');

/** 平台总览 */
function overview() {
  const users = db
    .prepare(
      `SELECT COUNT(*) AS total,
              SUM(CASE WHEN role = 'student' THEN 1 ELSE 0 END) AS students,
              SUM(CASE WHEN role = 'courier' THEN 1 ELSE 0 END) AS couriers,
              SUM(CASE WHEN role = 'admin' THEN 1 ELSE 0 END) AS admins
       FROM users`
    )
    .get();
  const orders = db
    .prepare(
      `SELECT COUNT(*) AS total,
              SUM(CASE WHEN status = 'pending'   THEN 1 ELSE 0 END) AS pending,
              SUM(CASE WHEN status = 'accepted'  THEN 1 ELSE 0 END) AS accepted,
              SUM(CASE WHEN status = 'picked'    THEN 1 ELSE 0 END) AS picked,
              SUM(CASE WHEN status = 'delivered' THEN 1 ELSE 0 END) AS delivered,
              SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS completed,
              SUM(CASE WHEN status IN ('cancelled','expired') THEN 1 ELSE 0 END) AS cancelled
       FROM orders`
    )
    .get();
  const gmv = db
    .prepare(`SELECT COALESCE(SUM(fee + tip), 0) AS v FROM orders WHERE status = 'completed'`)
    .get().v;
  const frozen = db
    .prepare(`SELECT COALESCE(SUM(fee + tip), 0) AS v FROM orders WHERE status IN ('pending','accepted','picked','delivered')`)
    .get().v;
  const today = nowStr().slice(0, 10);
  const todayOrders = db
    .prepare(`SELECT COUNT(*) AS n FROM orders WHERE created_at LIKE ?`)
    .get(`${today}%`).n;
  const todayUsers = db
    .prepare(`SELECT COUNT(*) AS n FROM users WHERE created_at LIKE ?`)
    .get(`${today}%`).n;
  return {
    users: {
      total: users.total,
      students: users.students || 0,
      couriers: users.couriers || 0,
      admins: users.admins || 0,
      todayNew: todayUsers,
    },
    orders: {
      total: orders.total,
      pending: orders.pending || 0,
      accepted: orders.accepted || 0,
      picked: orders.picked || 0,
      delivered: orders.delivered || 0,
      completed: orders.completed || 0,
      cancelled: orders.cancelled || 0,
      todayNew: todayOrders,
    },
    gmv,
    frozen,
  };
}

/** 用户列表 */
function listUsers({ query }) {
  const { page, pageSize, offset } = paginate(query);
  const q = (query.q || '').trim();
  const where = q ? 'WHERE username LIKE ? OR nickname LIKE ? OR phone LIKE ?' : '';
  const args = q ? [`%${q}%`, `%${q}%`, `%${q}%`] : [];
  const total = db.prepare(`SELECT COUNT(*) AS n FROM users ${where}`).get(...args).n;
  const list = db
    .prepare(
      `SELECT id, username, nickname, role, phone, dorm, balance, status, created_at AS createdAt,
              (SELECT COUNT(*) FROM orders o WHERE o.publisher_id = users.id) AS publishCount,
              (SELECT COUNT(*) FROM orders o WHERE o.courier_id = users.id AND o.status = 'completed') AS serveCount
       FROM users ${where} ORDER BY id ASC LIMIT ? OFFSET ?`
    )
    .all(...args, pageSize, offset);
  return { list, total, page, pageSize };
}

/** 启用/禁用用户 */
function setUserStatus({ params, body, user }) {
  const id = Number(params.id);
  const status = pickEnum(body, 'status', ['active', 'banned'], { label: '状态' });
  if (id === user.id) fail(400, '不能修改自己的账号状态');
  const target = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  if (!target) fail(404, '用户不存在');
  db.prepare('UPDATE users SET status = ? WHERE id = ?').run(status, id);
  addNotify(id, 'system', status === 'banned' ? '账号已被禁用' : '账号已恢复', status === 'banned' ? '如有疑问请联系平台管理员。' : '您的账号已恢复正常。', null);
  return toPublicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(id));
}

/** 订单列表（全量监管） */
function listOrders({ query }) {
  const { page, pageSize, offset } = paginate(query);
  const q = (query.q || '').trim();
  const status = (query.status || '').trim();
  const STATUSES = ['pending', 'accepted', 'picked', 'delivered', 'completed', 'cancelled', 'expired'];
  const where = [];
  const args = [];
  if (status) {
    if (!STATUSES.includes(status)) fail(400, '订单状态筛选值不合法');
    where.push('o.status = ?');
    args.push(status);
  }
  if (q) {
    where.push('(o.order_no LIKE ? OR o.tracking_no LIKE ? OR o.express_company LIKE ? OR p.nickname LIKE ? OR c.nickname LIKE ?)');
    for (let i = 0; i < 5; i++) args.push(`%${q}%`);
  }
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const total = db
    .prepare(`SELECT COUNT(*) AS n FROM orders o LEFT JOIN users p ON p.id = o.publisher_id LEFT JOIN users c ON c.id = o.courier_id ${whereSql}`)
    .get(...args).n;
  const list = db
    .prepare(
      `SELECT o.id, o.order_no AS orderNo, o.express_company AS expressCompany, o.tracking_no AS trackingNo,
              o.pickup_point AS pickupPoint, o.delivery_address AS deliveryAddress,
              o.fee, o.tip, o.status, o.created_at AS createdAt,
              p.nickname AS publisherName, c.nickname AS courierName
       FROM orders o
       LEFT JOIN users p ON p.id = o.publisher_id
       LEFT JOIN users c ON c.id = o.courier_id
       ${whereSql} ORDER BY o.created_at DESC, o.id DESC LIMIT ? OFFSET ?`
    )
    .all(...args, pageSize, offset);
  return { list, total, page, pageSize };
}

/** 管理员强制取消（未完成订单全额退款） */
function forceCancel({ params, body }) {
  const id = Number(params.id);
  const reason = pickStr(body, 'reason', { min: 1, max: 100, label: '处理原因' });
  return withTx(() => {
    const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(id);
    if (!order) fail(404, '订单不存在');
    if (['completed', 'cancelled', 'expired'].includes(order.status)) fail(409, '该订单已结束，无需处理');
    const r = db
      .prepare(
        `UPDATE orders SET status = 'cancelled', cancelled_at = ?, cancel_reason = ?
         WHERE id = ? AND status NOT IN ('completed','cancelled','expired')`
      )
      .run(nowStr(), `[管理员] ${reason}`, id);
    if (!r.changes) fail(409, '订单状态已变更');

    const total = order.fee + order.tip;
    addTransaction(order.publisher_id, 'escrow_refund', total, id, '管理员介入退款');
    addNotify(order.publisher_id, 'order', '订单已被管理员取消', `原因：${reason}。¥${(total / 100).toFixed(2)} 已退回余额。`, id);
    if (order.courier_id) {
      addNotify(order.courier_id, 'order', '订单已被管理员取消', `原因：${reason}。请勿继续配送。`, id);
    }
    return { id: order.id, status: 'cancelled' };
  });
}

module.exports = [
  { method: 'GET', path: '/api/admin/overview', role: 'admin', handler: overview },
  { method: 'GET', path: '/api/admin/users', role: 'admin', handler: listUsers },
  { method: 'PUT', path: '/api/admin/users/:id/status', role: 'admin', handler: setUserStatus },
  { method: 'GET', path: '/api/admin/orders', role: 'admin', handler: listOrders },
  { method: 'POST', path: '/api/admin/orders/:id/force-cancel', role: 'admin', handler: forceCancel },
];
