'use strict';
/**
 * 站内消息路由
 */
const { db } = require('../db');
const { fail, paginate } = require('../util');

function listNotifications({ query, user }) {
  const { page, pageSize, offset } = paginate(query, 15, 50);
  const unreadOnly = String(query.unread || '') === '1';
  const where = unreadOnly ? 'WHERE user_id = ? AND is_read = 0' : 'WHERE user_id = ?';
  const total = db.prepare(`SELECT COUNT(*) AS n FROM notifications ${where}`).get(user.id).n;
  const list = db
    .prepare(
      `SELECT id, type, title, content, order_id AS orderId, is_read AS isRead, created_at AS createdAt
       FROM notifications ${where} ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?`
    )
    .all(user.id, pageSize, offset);
  const unread = db
    .prepare('SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND is_read = 0')
    .get(user.id).n;
  return { list, total, unread, page, pageSize };
}

/** 标记已读：ids 数组 或 all=true */
function markRead({ body, user }) {
  const all = body && body.all === true;
  const ids = body && Array.isArray(body.ids) ? body.ids.filter((n) => Number.isInteger(Number(n))).map(Number) : [];
  if (!all && ids.length === 0) fail(400, '请选择要标记的消息');
  if (all) {
    db.prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?').run(user.id);
  } else {
    if (ids.length > 200) fail(400, '一次最多标记 200 条');
    const placeholders = ids.map(() => '?').join(',');
    db.prepare(`UPDATE notifications SET is_read = 1 WHERE user_id = ? AND id IN (${placeholders})`).run(user.id, ...ids);
  }
  const unread = db
    .prepare('SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND is_read = 0')
    .get(user.id).n;
  return { unread };
}

module.exports = [
  { method: 'GET', path: '/api/notifications', auth: true, handler: listNotifications },
  { method: 'POST', path: '/api/notifications/read', auth: true, handler: markRead },
];
