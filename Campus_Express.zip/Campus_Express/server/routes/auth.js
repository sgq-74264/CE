'use strict';
/**
 * 认证与用户相关路由
 */
const { db } = require('../db');
const { hashPassword, verifyPassword, signToken } = require('../auth');
const { fail, pickStr, pickEnum, toPublicUser, nowStr } = require('../util');

const USERNAME_RE = /^[a-zA-Z0-9_一-龥]+$/;
const PHONE_RE = /^1\d{10}$/;

module.exports = [
  {
    method: 'POST',
    path: '/api/auth/register',
    handler: ({ body }) => {
      const username = pickStr(body, 'username', { min: 3, max: 20, pattern: USERNAME_RE, label: '用户名' });
      const password = pickStr(body, 'password', { min: 6, max: 32, label: '密码' });
      const nickname = pickStr(body, 'nickname', { min: 1, max: 20, label: '昵称' });
      const role = pickEnum(body, 'role', ['student', 'courier'], { label: '身份' });
      const phone = pickStr(body, 'phone', { required: false, max: 11, pattern: PHONE_RE, label: '手机号' });
      const dorm = pickStr(body, 'dorm', { required: false, max: 50, label: '宿舍/地址' });

      const exists = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
      if (exists) fail(409, '用户名已被注册');

      const info = db
        .prepare(
          `INSERT INTO users (username, password_hash, nickname, role, phone, dorm, balance, created_at)
           VALUES (?, ?, ?, ?, ?, ?, 0, ?)`
        )
        .run(username, hashPassword(password), nickname, role, phone, dorm, nowStr());

      const user = db.prepare('SELECT * FROM users WHERE id = ?').get(Number(info.lastInsertRowid));
      return { token: signToken(user.id), user: toPublicUser(user) };
    },
  },
  {
    method: 'POST',
    path: '/api/auth/login',
    handler: ({ body }) => {
      const username = pickStr(body, 'username', { min: 1, max: 20, label: '用户名' });
      const password = pickStr(body, 'password', { min: 1, max: 32, label: '密码' });
      const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
      // 用户名与密码错误提示一致，避免枚举账号
      if (!user || !verifyPassword(password, user.password_hash)) fail(401, '用户名或密码错误');
      if (user.status === 'banned') fail(403, '账号已被禁用，请联系管理员');
      return { token: signToken(user.id), user: toPublicUser(user) };
    },
  },
  {
    method: 'GET',
    path: '/api/me',
    auth: true,
    handler: ({ user }) => toPublicUser(user),
  },
  {
    method: 'PUT',
    path: '/api/me',
    auth: true,
    handler: ({ user, body }) => {
      const nickname = pickStr(body, 'nickname', { required: false, min: 1, max: 20, def: user.nickname, label: '昵称' });
      const phone = pickStr(body, 'phone', { required: false, max: 11, def: user.phone, pattern: user.phone || body.phone ? PHONE_RE : null, label: '手机号' });
      const dorm = pickStr(body, 'dorm', { required: false, max: 50, def: user.dorm, label: '宿舍/地址' });
      const bio = pickStr(body, 'bio', { required: false, max: 100, def: user.bio, label: '简介' });
      db.prepare('UPDATE users SET nickname = ?, phone = ?, dorm = ?, bio = ? WHERE id = ?').run(
        nickname, phone, dorm, bio, user.id
      );
      return toPublicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(user.id));
    },
  },
  {
    method: 'PUT',
    path: '/api/me/password',
    auth: true,
    handler: ({ user, body }) => {
      const oldPassword = pickStr(body, 'oldPassword', { min: 1, max: 32, label: '原密码' });
      const newPassword = pickStr(body, 'newPassword', { min: 6, max: 32, label: '新密码' });
      if (!verifyPassword(oldPassword, user.password_hash)) fail(400, '原密码不正确');
      if (oldPassword === newPassword) fail(400, '新密码不能与原密码相同');
      db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hashPassword(newPassword), user.id);
      return { message: '密码修改成功' };
    },
  },
  {
    method: 'GET',
    path: '/api/users/:id',
    auth: true,
    handler: ({ params }) => {
      const id = Number(params.id);
      const u = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
      if (!u) fail(404, '用户不存在');

      const courierStat = db
        .prepare(
          `SELECT COUNT(*) AS completed,
                  AVG(rating) AS avgRating,
                  COUNT(rating) AS ratingCount
           FROM orders WHERE courier_id = ? AND status = 'completed'`
        )
        .get(id);
      const publishStat = db
        .prepare(`SELECT COUNT(*) AS published FROM orders WHERE publisher_id = ?`)
        .get(id);
      const reviews = db
        .prepare(
          `SELECT o.rating, o.review, o.created_at AS createdAt, o.order_no AS orderNo,
                  p.nickname AS publisherName
           FROM orders o LEFT JOIN users p ON p.id = o.publisher_id
           WHERE o.courier_id = ? AND o.review IS NOT NULL AND o.review != ''
           ORDER BY o.reviewed_at DESC LIMIT 10`
        )
        .all(id);

      return {
        user: toPublicUser(u),
        stats: {
          courierCompleted: courierStat.completed,
          avgRating: courierStat.avgRating ? Math.round(courierStat.avgRating * 10) / 10 : null,
          ratingCount: courierStat.ratingCount,
          published: publishStat.published,
        },
        reviews,
      };
    },
  },
];
