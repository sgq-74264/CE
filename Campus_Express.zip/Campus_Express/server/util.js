'use strict';
/**
 * 通用工具：错误类型、参数校验、时间/分页/流水号辅助函数
 */
const crypto = require('node:crypto');

class ApiError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

/** 抛出一个带 HTTP 状态码的业务错误 */
const fail = (status, message) => {
  throw new ApiError(status, message);
};

/** 字符串参数校验 */
function pickStr(body, key, opt = {}) {
  const { required = true, min = 0, max = 255, def = '', pattern = null, label = key } = opt;
  let v = body ? body[key] : undefined;
  if (v === undefined || v === null || v === '') {
    if (required) fail(400, `${label}不能为空`);
    return def;
  }
  if (typeof v !== 'string') fail(400, `${label}格式不正确`);
  v = v.trim();
  if (required && v.length === 0) fail(400, `${label}不能为空`);
  if (v.length < min) fail(400, `${label}至少需要 ${min} 个字符`);
  if (v.length > max) fail(400, `${label}最多 ${max} 个字符`);
  if (pattern && !pattern.test(v)) fail(400, `${label}格式不正确`);
  return v;
}

/** 整数参数校验（金额统一用「分」存储，杜绝浮点误差） */
function pickInt(body, key, opt = {}) {
  const { required = true, min = -Infinity, max = Infinity, def = 0, label = key } = opt;
  let v = body ? body[key] : undefined;
  if (v === undefined || v === null || v === '') {
    if (required) fail(400, `${label}不能为空`);
    return def;
  }
  const n = typeof v === 'number' ? v : Number(v);
  if (!Number.isInteger(n)) fail(400, `${label}必须是整数`);
  if (n < min) fail(400, `${label}不能小于 ${min}`);
  if (n > max) fail(400, `${label}不能大于 ${max}`);
  return n;
}

/** 枚举参数校验 */
function pickEnum(body, key, allowed, opt = {}) {
  const { required = true, def = allowed[0], label = key } = opt;
  const v = body ? body[key] : undefined;
  if (v === undefined || v === null || v === '') {
    if (required) fail(400, `${label}不能为空`);
    return def;
  }
  if (!allowed.includes(v)) fail(400, `${label}取值不合法`);
  return v;
}

/** 本地时间字符串 YYYY-MM-DD HH:MM:SS（便于 SQLite 文本列做字典序比较） */
function nowStr(offsetMs = 0) {
  const d = new Date(Date.now() + offsetMs);
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

/** 把前端 datetime-local（YYYY-MM-DDTHH:MM）统一转为存储格式 */
function normalizeDateTime(input, label = '时间') {
  const s = String(input).trim();
  const m = s.match(/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2}))?$/);
  if (!m) fail(400, `${label}格式不正确`);
  const dt = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]), Number(m[4]), Number(m[5]), Number(m[6] || 0));
  if (Number.isNaN(dt.getTime())) fail(400, `${label}不是有效时间`);
  return nowStr(dt.getTime() - Date.now());
}

/** 生成订单号：EX + 日期 + 6 位随机大写十六进制 */
function genOrderNo() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  const stamp = `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}`;
  return `EX${stamp}${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
}

/** 分页参数 */
function paginate(query = {}, defSize = 10, maxSize = 50) {
  let page = Number(query.page || 1);
  let pageSize = Number(query.pageSize || defSize);
  if (!Number.isInteger(page) || page < 1) page = 1;
  if (!Number.isInteger(pageSize) || pageSize < 1) pageSize = defSize;
  if (pageSize > maxSize) pageSize = maxSize;
  return { page, pageSize, offset: (page - 1) * pageSize };
}

/** 对外用户信息（剔除密码散列等敏感字段） */
function toPublicUser(row) {
  if (!row) return null;
  return {
    id: row.id,
    username: row.username,
    nickname: row.nickname,
    role: row.role,
    phone: row.phone || '',
    dorm: row.dorm || '',
    bio: row.bio || '',
    balance: row.balance,
    status: row.status,
    createdAt: row.created_at || row.createdAt,
  };
}

/** 金额展示：分 → 元（字符串，两位小数） */
const fenToYuan = (fen) => (Number(fen) / 100).toFixed(2);

module.exports = {
  ApiError,
  fail,
  pickStr,
  pickInt,
  pickEnum,
  nowStr,
  normalizeDateTime,
  genOrderNo,
  paginate,
  toPublicUser,
  fenToYuan,
};
