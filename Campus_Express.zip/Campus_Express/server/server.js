'use strict';
/**
 * 服务器入口：REST 路由分发 + 静态前端托管
 * 启动：node server/server.js  （或 npm start）
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { db } = require('./db');
const { resolveUser } = require('./auth');
const { ApiError, fail } = require('./util');

const PORT = Number(process.env.PORT) || 3000;
const WEB_ROOT = path.resolve(__dirname, '..', 'web');
const MAX_BODY = 1024 * 1024; // 1MB

// ---------------------------------------------------------------------------
// 路由装载（静态段多的路由优先匹配，避免 /api/orders/stats 被 /api/orders/:id 抢走）
// ---------------------------------------------------------------------------
const routeModules = ['./routes/auth', './routes/orders', './routes/wallet', './routes/notifications', './routes/admin'];
const routes = [];
for (const m of routeModules) routes.push(...require(m));
const splitPath = (p) => String(p).split('/').filter(Boolean);
routes.sort((a, b) => {
  const score = (r) => splitPath(r.path).filter((s) => !s.startsWith(':')).length;
  return score(b) - score(a);
});

function matchRoute(method, pathname) {
  const segs = splitPath(pathname);
  for (const r of routes) {
    if (r.method !== method) continue;
    const rSegs = splitPath(r.path);
    if (rSegs.length !== segs.length) continue;
    const params = {};
    let ok = true;
    for (let i = 0; i < rSegs.length; i++) {
      if (rSegs[i].startsWith(':')) params[rSegs[i].slice(1)] = decodeURIComponent(segs[i]);
      else if (rSegs[i] !== segs[i]) {
        ok = false;
        break;
      }
    }
    if (ok) return { route: r, params };
  }
  return null;
}

// ---------------------------------------------------------------------------
// 工具
// ---------------------------------------------------------------------------
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
};

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Cache-Control': 'no-store',
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY) {
        reject(new ApiError(413, '请求体过大'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (chunks.length === 0) return resolve({});
      try {
        const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'));
        if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
          return reject(new ApiError(400, '请求体必须是 JSON 对象'));
        }
        resolve(parsed);
      } catch (_) {
        reject(new ApiError(400, 'JSON 解析失败'));
      }
    });
    req.on('error', reject);
  });
}

function serveStatic(res, pathname) {
  let rel = decodeURIComponent(pathname);
  if (rel === '/' || rel === '') rel = '/index.html';
  const fp = path.join(WEB_ROOT, path.normalize(rel).replace(/^(\.\.(\/|\\|$))+/, ''));
  if (fp !== WEB_ROOT && !fp.startsWith(WEB_ROOT + path.sep)) {
    sendJson(res, 403, { success: false, message: '禁止访问' });
    return;
  }
  fs.stat(fp, (err, stat) => {
    if (err || !stat.isFile()) {
      // 未命中的路由交给前端路由处理
      const index = path.join(WEB_ROOT, 'index.html');
      fs.readFile(index, (e2, buf) => {
        if (e2) return sendJson(res, 404, { success: false, message: '页面不存在' });
        res.writeHead(200, { 'Content-Type': MIME['.html'], 'X-Content-Type-Options': 'nosniff' });
        res.end(buf);
      });
      return;
    }
    const ext = path.extname(fp).toLowerCase();
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Content-Length': stat.size,
      'X-Content-Type-Options': 'nosniff',
      'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=300',
    });
    fs.createReadStream(fp).pipe(res);
  });
}

// ---------------------------------------------------------------------------
// 主流程
// ---------------------------------------------------------------------------
const server = http.createServer(async (req, res) => {
  const started = Date.now();
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = url.pathname;

  try {
    if (!pathname.startsWith('/api/')) {
      serveStatic(res, pathname);
      return;
    }

    const matched = matchRoute(req.method, pathname);
    if (!matched) {
      if (req.method === 'OPTIONS') {
        res.writeHead(204, { Allow: 'GET, POST, PUT, DELETE' });
        res.end();
        return;
      }
      sendJson(res, 404, { success: false, message: '接口不存在' });
      return;
    }

    const { route, params } = matched;
    const body = ['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method) ? await readBody(req) : {};
    const query = Object.fromEntries(url.searchParams.entries());

    let user = null;
    if (route.auth || route.role) {
      user = resolveUser(req, db);
      if (route.role && user.role !== route.role) fail(403, '无权访问该功能');
    }

    const data = await route.handler({ req, res, params, query, body, user });
    sendJson(res, 200, { success: true, data: data === undefined ? null : data });
  } catch (err) {
    if (err instanceof ApiError) {
      sendJson(res, err.status, { success: false, message: err.message });
    } else {
      console.error(`[ERROR] ${req.method} ${pathname}`, err);
      sendJson(res, 500, { success: false, message: '服务器内部错误' });
    }
  } finally {
    if (pathname.startsWith('/api/')) {
      console.log(`${req.method} ${pathname} ${Date.now() - started}ms`);
    }
  }
});

server.listen(PORT, () => {
  console.log('==============================================');
  console.log('  校园快递代取平台已启动');
  console.log(`  ➜ 前端页面:  http://localhost:${PORT}`);
  console.log(`  ➜ 数据文件:  data/app.db（首次启动自动初始化演示数据）`);
  console.log('  演示账号: admin/admin123  xiaoming/123456  paotui1/123456');
  console.log('==============================================');
});
