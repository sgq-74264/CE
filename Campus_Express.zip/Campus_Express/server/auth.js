'use strict';
/**
 * 认证：密码散列（scrypt + 随机盐）、HMAC 签名令牌（无第三方依赖）
 */
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { fail } = require('./util');

const SECRET_PATH = path.join(__dirname, '..', 'data', 'secret.key');

function loadSecret() {
  fs.mkdirSync(path.dirname(SECRET_PATH), { recursive: true });
  try {
    const buf = fs.readFileSync(SECRET_PATH);
    if (buf.length >= 32) return buf;
  } catch (_) {
    /* 首次运行，生成新密钥 */
  }
  const secret = crypto.randomBytes(32);
  fs.writeFileSync(SECRET_PATH, secret);
  return secret;
}

const SECRET = loadSecret();
const TOKEN_TTL_MS = 7 * 24 * 60 * 60 * 1000; // 7 天

/** 生成密码散列，格式：saltHex:hashHex */
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(password), salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

/** 恒定时间比较，防止时序侧信道 */
function verifyPassword(password, stored) {
  if (typeof stored !== 'string') return false;
  const [salt, hash] = stored.split(':');
  if (!salt || !hash) return false;
  const calc = crypto.scryptSync(String(password), salt, 64);
  const expected = Buffer.from(hash, 'hex');
  return calc.length === expected.length && crypto.timingSafeEqual(calc, expected);
}

const b64url = (input) => Buffer.from(input).toString('base64url');

/** 签发令牌：payload.signature（base64url + HMAC-SHA256） */
function signToken(uid) {
  const payload = b64url(JSON.stringify({ uid, exp: Date.now() + TOKEN_TTL_MS }));
  const sig = crypto.createHmac('sha256', SECRET).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}

/** 校验令牌，失败返回 null */
function verifyToken(token) {
  if (typeof token !== 'string' || !token.includes('.')) return null;
  const [payload, sig] = token.split('.');
  if (!payload || !sig) return null;
  const expect = crypto.createHmac('sha256', SECRET).update(payload).digest('base64url');
  const a = Buffer.from(sig);
  const b = Buffer.from(expect);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    if (!data || !Number.isInteger(data.uid) || Date.now() > data.exp) return null;
    return data;
  } catch (_) {
    return null;
  }
}

/** 从请求头解析当前用户（供路由前置校验使用） */
function resolveUser(req, db) {
  const header = req.headers['authorization'] || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  const payload = verifyToken(token);
  if (!payload) fail(401, '请先登录');
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(payload.uid);
  if (!user) fail(401, '账号不存在或已注销');
  if (user.status === 'banned') fail(403, '账号已被禁用，请联系管理员');
  return user;
}

module.exports = { hashPassword, verifyPassword, signToken, verifyToken, resolveUser };
