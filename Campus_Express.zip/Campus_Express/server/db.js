'use strict';
/**
 * SQLite 初始化：建表、索引、演示数据
 * 金额一律以「分」为单位的整数存储，避免浮点误差。
 */
const path = require('node:path');
const fs = require('node:fs');
const { DatabaseSync } = require('node:sqlite');
const { hashPassword } = require('./auth');
const { nowStr, genOrderNo, fail } = require('./util');

const DATA_DIR = path.join(__dirname, '..', 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });

const db = new DatabaseSync(path.join(DATA_DIR, 'app.db'));
db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;

  CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT    NOT NULL UNIQUE,
    password_hash TEXT    NOT NULL,
    nickname      TEXT    NOT NULL,
    role          TEXT    NOT NULL DEFAULT 'student',   -- student | courier | admin
    phone         TEXT    NOT NULL DEFAULT '',
    dorm          TEXT    NOT NULL DEFAULT '',
    bio           TEXT    NOT NULL DEFAULT '',
    balance       INTEGER NOT NULL DEFAULT 0,           -- 可用余额（分）
    status        TEXT    NOT NULL DEFAULT 'active',    -- active | banned
    created_at    TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
  );

  CREATE TABLE IF NOT EXISTS orders (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    order_no         TEXT    NOT NULL UNIQUE,
    publisher_id     INTEGER NOT NULL REFERENCES users(id),
    courier_id       INTEGER          REFERENCES users(id),
    express_company  TEXT    NOT NULL,
    tracking_no      TEXT    NOT NULL,
    pickup_point     TEXT    NOT NULL,
    delivery_address TEXT    NOT NULL,
    item_desc        TEXT    NOT NULL DEFAULT '',
    size             TEXT    NOT NULL DEFAULT 'medium', -- small | medium | large
    fee              INTEGER NOT NULL,                  -- 基础代取费（分）
    tip              INTEGER NOT NULL DEFAULT 0,        -- 加急小费（分）
    status           TEXT    NOT NULL DEFAULT 'pending',
    -- pending 待接单 | accepted 已接单 | picked 已取件 | delivered 已送达
    -- completed 已完成 | cancelled 已取消 | expired 已超时
    remark           TEXT    NOT NULL DEFAULT '',
    cancel_reason    TEXT    NOT NULL DEFAULT '',
    deadline         TEXT,                              -- 期望送达时间，超时未接单自动取消退款
    created_at       TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    accepted_at      TEXT,
    picked_at        TEXT,
    delivered_at     TEXT,
    completed_at     TEXT,
    cancelled_at     TEXT,
    rating           INTEGER,                           -- 1~5 星评价
    review           TEXT,
    reviewed_at      TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_orders_status     ON orders(status);
  CREATE INDEX IF NOT EXISTS idx_orders_publisher  ON orders(publisher_id);
  CREATE INDEX IF NOT EXISTS idx_orders_courier    ON orders(courier_id);
  CREATE INDEX IF NOT EXISTS idx_orders_created    ON orders(created_at);

  CREATE TABLE IF NOT EXISTS transactions (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL REFERENCES users(id),
    type          TEXT    NOT NULL,   -- recharge 充值 | withdraw 提现 | escrow_freeze 托管冻结
                                      -- escrow_release 结算到账 | escrow_refund 取消退款
    amount        INTEGER NOT NULL,   -- 正数入账 / 负数出账（分）
    balance_after INTEGER NOT NULL,
    order_id      INTEGER          REFERENCES orders(id),
    note          TEXT    NOT NULL DEFAULT '',
    created_at    TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE INDEX IF NOT EXISTS idx_tx_user ON transactions(user_id);

  CREATE TABLE IF NOT EXISTS notifications (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id),
    type       TEXT    NOT NULL DEFAULT 'system', -- order | wallet | system
    title      TEXT    NOT NULL,
    content    TEXT    NOT NULL DEFAULT '',
    order_id   INTEGER          REFERENCES orders(id),
    is_read    INTEGER NOT NULL DEFAULT 0,
    created_at TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE INDEX IF NOT EXISTS idx_notify_user ON notifications(user_id, is_read);
`);

/** 事务执行：BEGIN IMMEDIATE 保证写锁，避免并发下的资金竞态 */
function withTx(fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (err) {
    try {
      db.exec('ROLLBACK');
    } catch (_) {
      /* 已回滚 */
    }
    throw err;
  }
}

/**
 * 记账（必须在 withTx 中调用），返回最新余额。
 * 负数出账带余额条件，天然防并发透支；余额变动只在本函数内发生，保证幂等语义单一。
 */
function addTransaction(userId, type, amount, orderId, note) {
  const user = db.prepare('SELECT id FROM users WHERE id = ?').get(userId);
  if (!user) throw new Error(`记账失败：用户 ${userId} 不存在`);
  const r =
    amount < 0
      ? db.prepare('UPDATE users SET balance = balance + ? WHERE id = ? AND balance + ? >= 0').run(amount, userId, amount)
      : db.prepare('UPDATE users SET balance = balance + ? WHERE id = ?').run(amount, userId);
  if (!r.changes) fail(400, '余额不足');
  const balanceAfter = db.prepare('SELECT balance FROM users WHERE id = ?').get(userId).balance;
  db.prepare(
    `INSERT INTO transactions (user_id, type, amount, balance_after, order_id, note)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).run(userId, type, amount, balanceAfter, orderId || null, note || '');
  return balanceAfter;
}

/** 站内通知 */
function addNotify(userId, type, title, content, orderId) {
  if (!userId) return;
  db.prepare(
    `INSERT INTO notifications (user_id, type, title, content, order_id) VALUES (?, ?, ?, ?, ?)`
  ).run(userId, type, title, content || '', orderId || null);
}

// ---------------------------------------------------------------------------
// 演示数据（仅在空库时写入）
// ---------------------------------------------------------------------------
function seed() {
  const count = db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
  if (count > 0) return;

  const pw = hashPassword('123456');
  const adminPw = hashPassword('admin123');
  const insertUser = db.prepare(
    `INSERT INTO users (id, username, password_hash, nickname, role, phone, dorm, bio, balance, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );

  const users = [
    [1, 'admin', adminPw, '平台管理员', 'admin', '13800000000', '行政楼101', '平台运营', 0, nowStr(-30 * 86400000)],
    [2, 'xiaoming', pw, '小明', 'student', '13811112222', '3号宿舍楼 512', '计算机学院大三', 5000, nowStr(-25 * 86400000)],
    [3, 'xiaohong', pw, '小红', 'student', '13933334444', '7号宿舍楼 308', '外语学院大二', 3000, nowStr(-20 * 86400000)],
    [4, 'dayu', pw, '大宇', 'student', '13755556666', '5号宿舍楼 210', '机械学院大四', 2000, nowStr(-15 * 86400000)],
    [5, 'paotui1', pw, '飞毛腿小李', 'courier', '13666667777', '9号宿舍楼 118', '勤工助学，风雨无阻', 500, nowStr(-25 * 86400000)],
    [6, 'paotui2', pw, '稳稳小王', 'courier', '13588889999', '2号宿舍楼 405', '细心稳妥，好评如潮', 500, nowStr(-18 * 86400000)],
    [7, 'paotui3', pw, '极速小张', 'courier', '13412345678', '11号宿舍楼 606', '电动车配送，效率第一', 0, nowStr(-10 * 86400000)],
  ];
  for (const u of users) insertUser.run(...u);

  const insertOrder = db.prepare(
    `INSERT INTO orders (id, order_no, publisher_id, courier_id, express_company, tracking_no,
       pickup_point, delivery_address, item_desc, size, fee, tip, status, remark, deadline,
       created_at, accepted_at, picked_at, delivered_at, completed_at, cancelled_at, rating, review, reviewed_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const insertTx = db.prepare(
    `INSERT INTO transactions (user_id, type, amount, balance_after, order_id, note, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  );
  const insertNotify = db.prepare(
    `INSERT INTO notifications (user_id, type, title, content, order_id, is_read, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  );

  // 订单演示数据：fee/tip 单位为分；流水与余额严格按照托管逻辑对账
  const orders = [
    // 1. 已完成 + 五星好评（小明发布，小李送达）
    {
      id: 1, publisher: 2, courier: 5, express: '顺丰速运', no: 'SF1234567890',
      pickup: '东区菜鸟驿站', addr: '3号宿舍楼 512', item: '文件袋（重要材料）', size: 'small',
      fee: 500, tip: 0, status: 'completed', remark: '请轻拿轻放',
      deadline: nowStr(-2 * 86400000),
      created: nowStr(-3 * 86400000), accepted: nowStr(-3 * 86400000 + 600000),
      picked: nowStr(-3 * 86400000 + 1500000), delivered: nowStr(-3 * 86400000 + 2700000),
      completed: nowStr(-3 * 86400000 + 2800000), rating: 5,
      review: '小李速度超快，文件完好无损，好评！', reviewed: nowStr(-3 * 86400000 + 2900000),
    },
    // 2. 已完成 + 四星评价（小红发布，小王送达）
    {
      id: 2, publisher: 3, courier: 6, express: '中通快递', no: 'ZT9876543210',
      pickup: '西区快递中心', addr: '7号宿舍楼 308', item: '两箱零食', size: 'large',
      fee: 500, tip: 100, status: 'completed', remark: '',
      deadline: nowStr(-4 * 86400000),
      created: nowStr(-5 * 86400000), accepted: nowStr(-5 * 86400000 + 900000),
      picked: nowStr(-5 * 86400000 + 2400000), delivered: nowStr(-5 * 86400000 + 3600000),
      completed: nowStr(-5 * 86400000 + 3700000), rating: 4,
      review: '东西有点重，辛苦了，服务很耐心。', reviewed: nowStr(-5 * 86400000 + 3800000),
    },
    // 3. 已送达，等待确认（小明发布，小王配送中）
    {
      id: 3, publisher: 2, courier: 6, express: '京东物流', no: 'JD5566778899',
      pickup: '北区京东站点', addr: '3号宿舍楼 512', item: '机械键盘', size: 'medium',
      fee: 600, tip: 200, status: 'delivered', remark: '到了请电话联系',
      deadline: nowStr(1 * 86400000),
      created: nowStr(-6 * 3600000), accepted: nowStr(-5 * 3600000),
      picked: nowStr(-3 * 3600000), delivered: nowStr(-1 * 3600000),
    },
    // 4. 已取件，配送中（小红发布，小李配送）
    {
      id: 4, publisher: 3, courier: 5, express: '圆通速递', no: 'YT1122334455',
      pickup: '东区菜鸟驿站', addr: '7号宿舍楼 308', item: '冬季外套一件', size: 'medium',
      fee: 450, tip: 0, status: 'picked', remark: '',
      deadline: nowStr(2 * 86400000),
      created: nowStr(-4 * 3600000), accepted: nowStr(-3 * 3600000), picked: nowStr(-1 * 3600000),
    },
    // 5. 已接单，待取件（大宇发布，小张接单）
    {
      id: 5, publisher: 4, courier: 7, express: '韵达快递', no: 'YD6677889900',
      pickup: '南区韵达驿站', addr: '5号宿舍楼 210', item: '考研资料一箱', size: 'large',
      fee: 700, tip: 100, status: 'accepted', remark: '比较重，麻烦多留意',
      deadline: nowStr(3 * 86400000),
      created: nowStr(-2 * 3600000), accepted: nowStr(-1 * 3600000),
    },
    // 6. 待接单（小明发布）
    {
      id: 6, publisher: 2, courier: null, express: '申通快递', no: 'ST3344556677',
      pickup: '西区快递中心', addr: '3号宿舍楼 512', item: '日用品若干', size: 'small',
      fee: 400, tip: 0, status: 'pending', remark: '今天下午六点前送到都可以',
      deadline: nowStr(5 * 3600000), created: nowStr(-30 * 60000),
    },
    // 7. 待接单（小红发布，加急）
    {
      id: 7, publisher: 3, courier: null, express: '顺丰速运', no: 'SF9988776655',
      pickup: '东区菜鸟驿站', addr: '7号宿舍楼 308', item: '生日礼物，加急！', size: 'small',
      fee: 550, tip: 300, status: 'pending', remark: '今晚生日前必须送到，谢谢',
      deadline: nowStr(3 * 3600000), created: nowStr(-15 * 60000),
    },
    // 8. 已取消（大宇发布后取消，已退款）
    {
      id: 8, publisher: 4, courier: null, express: '邮政EMS', no: 'EMS123123123',
      pickup: '校门口邮政所', addr: '5号宿舍楼 210', item: '证件材料', size: 'small',
      fee: 300, tip: 0, status: 'cancelled', remark: '', cancelReason: '自己顺路取回，不需要代取了',
      deadline: nowStr(-1 * 86400000),
      created: nowStr(-2 * 86400000), cancelled: nowStr(-2 * 86400000 + 1800000),
    },
  ];

  for (const o of orders) {
    insertOrder.run(
      o.id, genOrderNo(), o.publisher, o.courier, o.express, o.no,
      o.pickup, o.addr, o.item, o.size, o.fee, o.tip, o.status, o.remark || '', o.deadline,
      o.created, o.accepted || null, o.picked || null, o.delivered || null,
      o.completed || null, o.cancelled || null, o.rating || null, o.review || null, o.reviewed || null
    );
  }
  // 按时间顺序重放全部资金变动，保证每条流水的 balance_after 与用户余额完全自洽：
  //  用户 2（小明）：+5000(充值) -500(#1) -800(#3) -400(#6) = 3300
  //  用户 3（小红）：+3000(充值) -600(#2) -450(#4) -850(#7) = 1100
  //  用户 4（大宇）：+2000(充值) -700(#5) -300(#8) +300(退款 #8) = 1300
  //  用户 5（小李）：+500(#1结算) = 500；用户 6（小王）：+600(#2结算) = 600
  const replay = [
    // [user, type, amount, order, note, time]
    [2, 'escrow_freeze', -500, 1, '订单托管冻结', nowStr(-3 * 86400000)],
    [5, 'escrow_release', 500, 1, '订单结算到账', nowStr(-3 * 86400000 + 2800000)],
    [3, 'escrow_freeze', -600, 2, '订单托管冻结', nowStr(-5 * 86400000)],
    [6, 'escrow_release', 600, 2, '订单结算到账', nowStr(-5 * 86400000 + 3700000)],
    [2, 'escrow_freeze', -800, 3, '订单托管冻结', nowStr(-6 * 3600000)],
    [3, 'escrow_freeze', -450, 4, '订单托管冻结', nowStr(-4 * 3600000)],
    [4, 'escrow_freeze', -700, 5, '订单托管冻结', nowStr(-2 * 3600000)],
    [2, 'escrow_freeze', -400, 6, '订单托管冻结', nowStr(-30 * 60000)],
    [3, 'escrow_freeze', -850, 7, '订单托管冻结', nowStr(-15 * 60000)],
    [4, 'escrow_freeze', -300, 8, '订单托管冻结', nowStr(-2 * 86400000)],
    [4, 'escrow_refund', 300, 8, '订单取消退款', nowStr(-2 * 86400000 + 1800000)],
    [2, 'recharge', 5000, null, '注册赠送体验金', nowStr(-25 * 86400000)],
    [3, 'recharge', 3000, null, '充值', nowStr(-20 * 86400000)],
    [4, 'recharge', 2000, null, '充值', nowStr(-15 * 86400000)],
  ];
  // 从 0 起重放全部资金变动（含充值），得到的余额即为最终正确余额
  const balanceMap = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0, 7: 0 };
  replay.sort((a, b) => (a[5] < b[5] ? -1 : 1));
  for (const [uid, type, amount, orderId, note, time] of replay) {
    balanceMap[uid] += amount;
    insertTx.run(uid, type, amount, balanceMap[uid], orderId, note, time);
  }
  // 对账：replay 结束后的余额同步回 users 表
  const fixBalance = db.prepare('UPDATE users SET balance = ? WHERE id = ?');
  fixBalance.run(balanceMap[2], 2);
  fixBalance.run(balanceMap[3], 3);
  fixBalance.run(balanceMap[4], 4);
  fixBalance.run(balanceMap[5], 5);
  fixBalance.run(balanceMap[6], 6);
  fixBalance.run(balanceMap[7], 7);

  const notifications = [
    [2, 'order', '订单已完成', '您的订单（顺丰速运 SF1234567890）已确认完成，感谢使用！', 1, 1, nowStr(-3 * 86400000 + 2800000)],
    [5, 'order', '收到五星好评', '用户「小明」对您的服务评价：小李速度超快，文件完好无损，好评！', 1, 1, nowStr(-3 * 86400000 + 2900000)],
    [3, 'order', '订单已完成', '您的订单（中通快递 ZT9876543210）已确认完成。', 2, 1, nowStr(-5 * 86400000 + 3700000)],
    [2, 'order', '跑腿员已取件', '「稳稳小王」已取到您的快递（京东物流 JD5566778899），配送中。', 3, 0, nowStr(-3 * 3600000)],
    [6, 'order', '新任务提醒', '您有新的代取任务待取件，请尽快处理。', 3, 0, nowStr(-5 * 3600000)],
    [2, 'wallet', '余额变动', '订单托管冻结 ¥4.00，当前余额 ¥33.00。', 6, 0, nowStr(-30 * 60000)],
    [3, 'order', '有新的加急任务', '您的加急订单（顺丰速运 SF9988776655）已发布，正在等待接单。', 7, 0, nowStr(-15 * 60000)],
    [4, 'wallet', '退款到账', '订单取消，托管金额 ¥3.00 已退回余额。', 8, 1, nowStr(-2 * 86400000 + 1800000)],
    [7, 'system', '欢迎加入校园代取平台', '完善接单地址与联系方式，可提升接单效率。', null, 1, nowStr(-10 * 86400000)],
  ];
  for (const n of notifications) insertNotify.run(...n);
}

seed();

module.exports = { db, withTx, addTransaction, addNotify };
